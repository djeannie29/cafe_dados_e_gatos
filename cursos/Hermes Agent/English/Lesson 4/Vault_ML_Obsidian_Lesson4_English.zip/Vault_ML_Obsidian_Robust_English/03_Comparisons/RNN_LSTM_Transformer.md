# RNN vs LSTM/GRU vs Transformer

## RNN
Simple recurrence and sequential state.

## LSTM/GRU
Memory mechanisms for longer dependencies.

## Transformer
Attention and more parallelizable processing.

## Relationship
All can work with sequences, but they use different architectures to represent dependencies.
