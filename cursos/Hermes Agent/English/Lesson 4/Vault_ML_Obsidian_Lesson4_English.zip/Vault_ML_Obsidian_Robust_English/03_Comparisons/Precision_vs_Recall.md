# Precision vs Recall

Precision answers: among predicted positives, how many were correct?

Recall answers: among actual positives, how many were found?

The priority depends on the cost of false positives and false negatives.
