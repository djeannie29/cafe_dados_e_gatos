# Regression vs Classification

## Regression
Predicts continuous values.

## Classification
Predicts categories.

## Example
House price: regression.
Low/medium/high risk level: classification.

## Evaluation
The metrics are different because the output types are also different.
