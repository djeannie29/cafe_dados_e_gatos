# K-Means vs DBSCAN

## K-Means
- requires k;
- uses centroids;
- favors compact clusters.

## DBSCAN
- uses density;
- does not require the number of clusters;
- identifies noise;
- can find irregular shapes.
