# MAE vs RMSE

MAE treats errors linearly. RMSE emphasizes large errors.

Use MAE when you want a measure that is more robust to extreme values. Use RMSE when large errors are especially costly.
