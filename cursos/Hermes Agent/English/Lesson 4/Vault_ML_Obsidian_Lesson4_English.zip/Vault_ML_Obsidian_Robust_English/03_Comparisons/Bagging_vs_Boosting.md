# Bagging vs Boosting

## Bagging
Trains multiple models relatively independently and combines their outputs.

## Boosting
Trains models sequentially, trying to correct previous errors.

## Typical objective
Bagging helps reduce variance. Boosting can reduce bias and progressively improve fit.
