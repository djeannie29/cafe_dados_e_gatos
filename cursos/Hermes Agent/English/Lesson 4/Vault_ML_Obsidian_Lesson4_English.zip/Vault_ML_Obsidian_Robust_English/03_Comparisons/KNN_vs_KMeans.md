# KNN vs K-Means

## KNN
Supervised. Uses known labels and nearby neighbors to predict an output.

## K-Means
Unsupervised. Groups points into clusters using centroids.

## Important similarity
Both are sensitive to scale because they depend on distance.

## Central difference
KNN predicts an output from known examples. K-Means discovers groups without labels.
