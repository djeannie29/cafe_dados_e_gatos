# Case Study — Property Prices

## Problem
Predict property sale prices.

## Type
Supervised regression.

## Possible features
- area;
- number of bedrooms;
- location;
- property age.

## Metrics
MAE and RMSE.

## Cautions
Outliers can affect RMSE. Location variables require appropriate representation.
