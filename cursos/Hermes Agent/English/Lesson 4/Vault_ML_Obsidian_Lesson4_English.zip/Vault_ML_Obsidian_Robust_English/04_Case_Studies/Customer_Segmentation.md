# Case Study — Customer Segmentation

## Problem
Group customers by behavioral patterns.

## Type
Clustering.

## Algorithms
K-Means or DBSCAN.

## Caution
The groups found must be interpreted with business context. A cluster is not automatically a real or causal profile.
