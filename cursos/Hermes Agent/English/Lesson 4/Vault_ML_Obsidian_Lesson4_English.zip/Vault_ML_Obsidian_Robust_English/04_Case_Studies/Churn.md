# Case Study — Churn

## Problem
Predict which customers may cancel a service.

## Type
Supervised classification.

## Challenge
If only a few customers cancel, the dataset may be imbalanced.

## Metrics
Precision, recall, F1-score, and the ROC curve may be more useful than accuracy alone.
