# Case Study — Image Classification

## Problem
Classify images into categories.

## Approach
Convolutional neural networks or modern vision architectures.

## Cautions
Separate training, validation, and test sets correctly. Avoid leakage between highly similar images.
