# Case Study — Fraud Detection

## Problem
Identify fraudulent transactions.

## Type
Classification.

## Challenge
Fraud cases are usually rare.

## Consequence
Accuracy can be misleading.

## Critical metric
Recall can be important for reducing undetected fraud, but precision also matters to avoid blocking legitimate transactions.
