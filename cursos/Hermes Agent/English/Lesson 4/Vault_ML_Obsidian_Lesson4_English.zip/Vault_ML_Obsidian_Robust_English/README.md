# Machine Learning Vault — Robust Version

This Vault was created for knowledge retrieval tests with Obsidian, OpenViking, and Hindsight.

## Structure

- `00_Maps`: concept maps and pipelines.
- `01_Topics`: main Machine Learning content.
- `02_Concepts`: cross-cutting concepts.
- `03_Comparisons`: comparisons between techniques and metrics.
- `04_Case_Studies`: applied examples.
- `05_Questions`: questions to test retrieval, relationships, and synthesis.

## Learning objective

The content was organized to support direct, comparative, and relational questions. Some ideas intentionally appear in more than one note to test semantic retrieval and synthesis across different files.
