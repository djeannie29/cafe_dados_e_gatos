# Overfitting and Validation

## Overfitting
The model learns training details and noise and loses its ability to generalize.

## Signs
- very good performance on training data;
- worse performance on validation or test data.

## Strategies
- cross-validation;
- regularization;
- model simplification;
- more data;
- early stopping in neural networks.

## Central relationship
Validation helps detect overfitting. Regularization helps reduce the model's effective complexity.
