# Neural Network Training

## Epoch
An epoch corresponds to one complete pass through the training dataset.

## Batch
A subset of examples processed before updating the parameters.

## Learning rate
Controls the size of parameter updates.

## Overfitting
Training for too many epochs can increase overfitting. Early stopping can stop training when validation performance stops improving.
