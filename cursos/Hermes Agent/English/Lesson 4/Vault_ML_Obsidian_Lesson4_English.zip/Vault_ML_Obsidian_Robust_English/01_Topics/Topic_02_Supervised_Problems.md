# Supervised Problems

## Concept
The model learns from examples with known inputs and outputs.

## Classification
The output belongs to a category.

Examples:
- fraud or not fraud;
- spam or not spam;
- flower species.

## Regression
The output is a continuous numerical value.

Examples:
- property price;
- energy consumption;
- delivery time.

## Cautions
The target variable must be defined correctly, and training and test data must be separated.
