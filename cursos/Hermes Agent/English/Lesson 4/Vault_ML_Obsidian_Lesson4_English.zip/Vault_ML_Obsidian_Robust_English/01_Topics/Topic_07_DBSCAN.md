# DBSCAN

## What it is
A density-based clustering algorithm.

## Advantages
- does not require defining the number of clusters in advance;
- can find groups with irregular shapes;
- identifies points as noise.

## Main parameters
- epsilon: neighborhood radius;
- min_samples: minimum number of points required to form a dense region.

## Limitations
It may struggle when clusters have very different densities.
