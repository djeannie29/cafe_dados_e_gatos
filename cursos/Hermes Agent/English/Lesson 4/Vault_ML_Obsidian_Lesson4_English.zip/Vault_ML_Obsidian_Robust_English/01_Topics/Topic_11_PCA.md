# PCA

## Objective
Reduce dimensionality while preserving as much data variance as possible.

## How it works
Creates new linear combinations called principal components.

## Interpretation
95% explained variance does not mean 95% accuracy in a classification task.

## Cautions
Scale can strongly influence PCA when variables have different magnitudes.
