# K-Means

## What it is
A clustering algorithm that divides data into k groups.

## How it works
It chooses centroids, assigns points to the nearest centroid, and updates the centroids iteratively.

## Scale
K-Means is also sensitive to scale because it uses distance to form groups.

## Limitations
- requires choosing k;
- works best with approximately compact and separable groups;
- can be affected by outliers.

## Interpretive caution
A cluster found by the algorithm is not automatically a real-world profile.
