# Evaluation and Production

## Evaluation
The model should be evaluated on data not used during training.

## Correct metric
The metric depends on the problem and the cost of errors.

## Production
A model may degrade as the data changes over time.

## Monitoring
It is important to track performance, data distribution, and possible behavioral changes.

## Key concept
Good training results do not guarantee good results in production.
