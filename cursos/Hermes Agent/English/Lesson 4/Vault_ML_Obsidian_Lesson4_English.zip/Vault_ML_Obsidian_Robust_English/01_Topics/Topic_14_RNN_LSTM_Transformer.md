# RNN, LSTM, GRU, and Transformers

## RNN
Processes sequences while maintaining a state over time, but struggles with long-term dependencies.

## LSTM and GRU
They were created to handle long-term dependencies better using mechanisms that control the flow of information.

## Transformers
Use attention to model relationships between sequence elements without relying on the same step-by-step recurrence used by RNNs.

## Comparison
Transformers tend to parallelize training better and capture long-range relationships more efficiently.
