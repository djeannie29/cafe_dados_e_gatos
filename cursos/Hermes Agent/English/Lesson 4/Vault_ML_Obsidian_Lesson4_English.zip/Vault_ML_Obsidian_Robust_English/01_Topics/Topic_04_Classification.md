# Classification

## Objective
Predict classes or categories.

## Examples
- positive or negative diagnosis;
- churn or retention;
- cat or dog image.

## Metrics
Accuracy, precision, recall, F1-score, confusion matrix.

## Imbalanced dataset
Accuracy can be misleading. A model that always predicts the majority class may look good without actually solving the problem.
