# Neural Networks

## Structure
Neural networks have neurons organized into layers.

## Components of a neuron
- inputs;
- weights;
- bias;
- activation function.

## Bias
Allows the decision function to shift. Without bias, some decision boundaries would be overly restricted.

## Learning
Weights and biases are adjusted to reduce a loss function.
