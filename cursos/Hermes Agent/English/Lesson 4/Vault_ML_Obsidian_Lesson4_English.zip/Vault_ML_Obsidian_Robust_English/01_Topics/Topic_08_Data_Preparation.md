# Data Preparation

## Objective
Transform raw data into data suitable for training and evaluation.

## Common steps
- handle missing values;
- remove duplicates when appropriate;
- correct data types;
- encode categories;
- normalize or standardize;
- create features.

## Relationship with evaluation
Poor data preparation can produce misleading results. If information from the test set leaks into training, data leakage occurs.
