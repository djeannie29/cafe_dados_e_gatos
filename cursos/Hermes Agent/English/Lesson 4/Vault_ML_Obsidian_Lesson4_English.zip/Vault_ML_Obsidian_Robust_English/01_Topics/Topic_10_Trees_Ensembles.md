# Trees and Ensembles

## Decision trees
Split data using successive rules.

## Bagging
Trains models on different samples and combines the results. Random Forest is a classic example.

## Boosting
Trains models sequentially, giving more attention to previous errors.

## Main difference
Bagging aims to reduce variance by combining models in parallel. Boosting aims to progressively correct errors.
