# KNN

## What it is
K-Nearest Neighbors is an algorithm based on proximity between examples.

## How it works
For a new point, it calculates distances, finds the k nearest neighbors, and uses those neighbors to determine the output.

## Role of k
A small k can make the model sensitive to noise. A large k can oversmooth the decision.

## Scale
KNN is highly sensitive to scale because it uses distance. Variables with larger ranges can dominate the calculation.

## Common mistakes
- forgetting normalization;
- choosing k without validation;
- assuming any distance metric is suitable for any problem.
