# AI, Machine Learning, and Deep Learning

## Artificial Intelligence
A field that brings together techniques for creating systems capable of performing tasks associated with intelligence.

## Machine Learning
A subfield of AI in which models learn patterns from data instead of relying only on manually programmed rules.

## Deep Learning
A subfield of Machine Learning based on neural networks with multiple layers.

## Relationships
AI is the broadest set. Machine Learning is within AI. Deep Learning is within Machine Learning.

## Common mistake
Treating AI, Machine Learning, and Deep Learning as synonyms.
