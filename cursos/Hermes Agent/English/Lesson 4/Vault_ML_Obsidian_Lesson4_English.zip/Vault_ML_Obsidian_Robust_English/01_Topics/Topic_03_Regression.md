# Regression

## Objective
Predict continuous numerical values.

## Examples
- house price;
- temperature;
- product demand.

## Metrics
MAE, RMSE, and R² are common.

## Cautions
A high R² does not prove causality. A good fit does not mean that one variable causes another.

## Relationship with generalization
A model may perform extremely well on training data and worse on new data if it is overfitting.
