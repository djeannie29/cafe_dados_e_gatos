# Cross-Validation

Cross-validation divides the data into multiple parts to repeat training and evaluation on different subsets.

## Objective
Obtain a more robust estimate of performance and help choose hyperparameters.

## Relationship
It is widely used to choose k in KNN, regularization parameters, and other settings.
