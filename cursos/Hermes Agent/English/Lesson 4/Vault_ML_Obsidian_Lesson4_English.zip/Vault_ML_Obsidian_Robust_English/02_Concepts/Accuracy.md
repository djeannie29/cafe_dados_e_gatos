# Accuracy

Accuracy is the proportion of correct predictions among all predictions.

## Limitation
In imbalanced datasets, it can hide poor performance on the minority class.

Example: if 99% of cases are negative, a model that always says "negative" will have 99% accuracy without identifying a single positive case.
