# Bias

## In neural networks
Bias is an additional parameter added to the weighted combination of inputs.

## In statistical learning
Bias can also mean the systematic error of a model that is too simple.

## Caution
The two meanings are related to the term "bias," but they are not exactly the same thing.
