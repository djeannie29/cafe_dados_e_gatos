# Feature Engineering

Feature engineering is the process of creating, transforming, or selecting useful features for the model.

## Examples
- extract the day of the week from a date;
- combine variables;
- create ratios;
- transform scales;
- encode categories.

## Caution
The transformation must be defined without using improper information from the test set.
