# Scale

Distance-based algorithms are sensitive to scale.

## Examples
- KNN;
- K-Means;
- PCA in many scenarios.

## Why
A variable with much larger values can dominate distance or variance measures.

## Strategies
- normalization;
- standardization.
