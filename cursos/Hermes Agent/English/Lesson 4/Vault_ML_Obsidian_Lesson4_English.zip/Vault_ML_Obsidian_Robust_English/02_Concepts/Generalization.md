# Generalization

Generalization is the model's ability to perform well on new data.

## Relationships
- overfitting reduces generalization;
- validation estimates generalization;
- regularization can improve generalization;
- production tests generalization under real-world conditions.
