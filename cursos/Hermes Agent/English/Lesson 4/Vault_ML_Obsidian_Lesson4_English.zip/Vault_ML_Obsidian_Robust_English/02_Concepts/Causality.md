# Causality

Correlation and predictive ability do not prove causality.

A model may use one variable to predict another even when there is no direct causal relationship between them.

Causal inference requires additional assumptions and study designs.
