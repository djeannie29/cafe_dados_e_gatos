# MAE and RMSE

## MAE
Mean of the absolute errors. It keeps the unit of the target variable.

## RMSE
Square root of the mean squared errors. It penalizes large errors more strongly.

## Choice
MAE may be preferable when large errors should not dominate the evaluation. RMSE may be useful when large errors are especially undesirable.
