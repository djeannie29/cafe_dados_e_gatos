# Data Leakage

Data leakage occurs when information that should not be available during training ends up influencing the model.

## Example
Standardizing the data using the mean and standard deviation calculated from the full dataset before splitting it into training and test sets.

## Consequence
Artificially optimistic evaluation results.
