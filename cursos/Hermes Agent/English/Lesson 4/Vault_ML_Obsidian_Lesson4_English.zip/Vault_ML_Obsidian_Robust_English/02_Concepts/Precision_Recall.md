# Precision and Recall

## Precision
Among the cases predicted as positive, how many were actually positive.

## Recall
Among the actual positive cases, how many were found.

## Trade-off
Changing the decision threshold can increase one metric and reduce the other.

## Example
In medical screening, recall can be very important for reducing false negatives.
