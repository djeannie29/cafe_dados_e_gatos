# Regularization

Regularization adds constraints or penalties to reduce excessive complexity.

## Objective
Improve generalization and reduce overfitting.

## Examples
- L1;
- L2;
- dropout in neural networks.
