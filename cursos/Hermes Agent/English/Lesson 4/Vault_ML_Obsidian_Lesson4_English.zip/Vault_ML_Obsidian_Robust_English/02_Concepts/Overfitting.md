# Overfitting

Overfitting happens when the model learns the training set too closely.

## Classic symptom
Very good training performance and worse validation performance.

## Reduction
- regularization;
- cross-validation;
- early stopping;
- more data;
- model simplification.
