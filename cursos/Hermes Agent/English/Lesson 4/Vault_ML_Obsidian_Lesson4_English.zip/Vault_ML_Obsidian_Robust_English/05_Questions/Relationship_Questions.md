# Relationship Questions

- Why are KNN and K-Means sensitive to scale even though they solve different problems?
- What is the relationship between overfitting, validation, and regularization?
- How can data leakage produce a misleading evaluation?
- How does generalization relate to training, validation, and production?
- What is the relationship between decision threshold, precision, and recall?
