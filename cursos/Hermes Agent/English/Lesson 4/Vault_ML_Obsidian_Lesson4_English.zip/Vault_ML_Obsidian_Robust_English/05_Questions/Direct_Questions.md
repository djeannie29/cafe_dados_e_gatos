# Direct Questions

- What is the difference between AI, Machine Learning, and Deep Learning?
- What characterizes a regression problem?
- What characterizes a classification problem?
- What is the role of k in KNN?
- What is an epoch in neural networks?
- What does bias do in a neuron?
- What is data leakage?
