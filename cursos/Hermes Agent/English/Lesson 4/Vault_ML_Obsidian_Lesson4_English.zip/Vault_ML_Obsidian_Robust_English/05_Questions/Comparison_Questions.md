# Comparison Questions

- Compare regression and classification.
- Compare bagging and boosting.
- Compare K-Means and DBSCAN.
- Compare RNN, LSTM/GRU, and Transformer.
- Compare MAE and RMSE.
- Compare precision and recall.
