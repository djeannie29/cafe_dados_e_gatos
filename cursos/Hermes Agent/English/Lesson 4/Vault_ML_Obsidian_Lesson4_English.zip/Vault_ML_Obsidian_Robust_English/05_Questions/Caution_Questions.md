# Questions That Require Care

- Does R² of 0.90 mean 90% of predictions are correct?
- Does 99% accuracy guarantee a good classifier?
- Does PCA with 95% explained variance guarantee 95% accuracy?
- Is a cluster automatically a real-world profile?
- Does a regression coefficient prove causality?
