# Synthesis Questions

- Describe a complete Machine Learning pipeline.
- Explain how a model can perform well in training and fail in production.
- Build a map connecting AI, Machine Learning, Neural Networks, Deep Learning, and Transformers.
- Explain why the best model depends on the problem, the metric, and the cost of errors.
- Which concepts appear repeatedly throughout this Vault?
