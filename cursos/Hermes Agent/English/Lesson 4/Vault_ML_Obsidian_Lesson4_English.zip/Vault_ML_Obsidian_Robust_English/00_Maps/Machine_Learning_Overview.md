# Machine Learning Overview

## Overview

Artificial Intelligence is a broad field. Machine Learning is a subfield of AI in which systems learn patterns from data. Deep Learning is a subset of Machine Learning based on deep neural networks.

## Main learning types

### Supervised learning
Uses examples with labels.

Common problems:
- classification;
- regression.

### Unsupervised learning
Works with data without explicit labels.

Common problems:
- clustering;
- dimensionality reduction;
- pattern detection.

### Reinforcement learning
An agent learns by interacting with an environment and receives rewards or penalties.

## Important relationships

- data preparation influences evaluation;
- scale affects distance-based algorithms;
- validation helps estimate generalization;
- regularization helps reduce overfitting;
- the best metric depends on the cost of errors;
- the best algorithm depends on the problem and the data.
