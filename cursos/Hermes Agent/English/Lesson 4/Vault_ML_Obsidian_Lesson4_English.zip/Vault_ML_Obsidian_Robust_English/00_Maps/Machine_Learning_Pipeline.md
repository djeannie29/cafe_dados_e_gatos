# Machine Learning Pipeline

## Main steps

1. Define the problem.
2. Identify the target variable, when applicable.
3. Collect and understand the data.
4. Handle missing and inconsistent data.
5. Perform feature engineering when necessary.
6. Split data into training, validation, and test sets.
7. Normalize or standardize when the algorithm is sensitive to scale.
8. Train candidate models.
9. Evaluate them with appropriate metrics.
10. Compare models.
11. Check overfitting and generalization.
12. Deploy and monitor the model.

## Cautions

Avoid data leakage. Transformations computed using the entire dataset can leak information from the test set into training.

Evaluation should reflect the real objective. Accuracy may be inappropriate for highly imbalanced datasets.
