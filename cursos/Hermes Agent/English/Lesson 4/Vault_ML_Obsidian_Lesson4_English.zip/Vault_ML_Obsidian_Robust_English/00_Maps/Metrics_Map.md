# Metrics Map

## Classification

### Accuracy
Overall proportion of correct predictions.

### Precision
Among the cases predicted as positive, how many were actually positive.

### Recall
Among the actual positive cases, how many were found.

### F1-score
Balances precision and recall using the harmonic mean.

## Regression

### MAE
Mean absolute error. Easier to interpret and less sensitive to outliers than RMSE.

### RMSE
Penalizes large errors more heavily.

### R²
Measures the proportion of variability explained by the model relative to a simple baseline. It does not mean the percentage of correct predictions.
