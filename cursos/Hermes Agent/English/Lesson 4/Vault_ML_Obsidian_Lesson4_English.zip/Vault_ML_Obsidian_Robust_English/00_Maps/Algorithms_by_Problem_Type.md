# Algorithms by Problem Type

## Classification
- Logistic regression
- KNN
- Decision trees
- Random Forest
- Gradient Boosting
- Neural networks

## Regression
- Linear regression
- KNN Regressor
- Regression trees
- Random Forest Regressor
- Gradient Boosting Regressor
- Neural networks

## Clustering
- K-Means
- DBSCAN
- Hierarchical clustering

## Dimensionality reduction
- PCA
- Autoencoders

## Sequences
- RNN
- LSTM
- GRU
- Transformers
