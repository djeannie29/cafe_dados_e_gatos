# Overfitting e Validação

## Overfitting
O modelo aprende detalhes e ruídos do treino e perde capacidade de generalizar.

## Sinais
- desempenho muito bom no treino;
- desempenho pior na validação ou teste.

## Estratégias
- validação cruzada;
- regularização;
- simplificação do modelo;
- mais dados;
- early stopping em redes neurais.

## Relação central
Validação ajuda a detectar overfitting. Regularização ajuda a reduzir a complexidade efetiva do modelo.
