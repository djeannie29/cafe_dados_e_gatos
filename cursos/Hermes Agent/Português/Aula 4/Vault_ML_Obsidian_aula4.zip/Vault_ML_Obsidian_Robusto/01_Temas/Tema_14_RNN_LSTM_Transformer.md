# RNN, LSTM, GRU e Transformers

## RNN
Processa sequências mantendo um estado ao longo do tempo, mas sofre com dependências longas.

## LSTM e GRU
Foram criadas para lidar melhor com dependências de longo prazo usando mecanismos de controle do fluxo de informação.

## Transformers
Usam atenção para modelar relações entre elementos da sequência sem depender da mesma recorrência passo a passo das RNNs.

## Comparação
Transformers tendem a paralelizar melhor o treinamento e capturar relações distantes com mais eficiência.
