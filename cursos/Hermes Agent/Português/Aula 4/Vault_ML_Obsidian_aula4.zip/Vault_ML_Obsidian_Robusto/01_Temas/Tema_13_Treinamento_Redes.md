# Treinamento de Redes Neurais

## Época
Uma época corresponde a uma passagem completa pelo conjunto de treinamento.

## Batch
Subconjunto de exemplos processados antes de atualizar os parâmetros.

## Learning rate
Controla o tamanho das atualizações dos parâmetros.

## Overfitting
Treinar por muitas épocas pode aumentar overfitting. Early stopping pode interromper o treino quando a validação deixa de melhorar.
