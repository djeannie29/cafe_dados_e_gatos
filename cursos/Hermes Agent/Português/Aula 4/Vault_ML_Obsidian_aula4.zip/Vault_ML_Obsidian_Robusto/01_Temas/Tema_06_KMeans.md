# K-Means

## O que é
Algoritmo de clustering que divide os dados em k grupos.

## Como funciona
Escolhe centróides, atribui pontos ao centróide mais próximo e atualiza os centróides iterativamente.

## Escala
K-Means também é sensível à escala porque utiliza distância para formar os grupos.

## Limitações
- exige escolher k;
- funciona melhor com grupos aproximadamente compactos e separáveis;
- pode ser afetado por outliers.

## Cuidado interpretativo
Um cluster encontrado pelo algoritmo não é automaticamente um perfil real do mundo.
