# Redes Neurais

## Estrutura
Redes neurais possuem neurônios organizados em camadas.

## Componentes de um neurônio
- entradas;
- pesos;
- bias;
- função de ativação.

## Bias
Permite deslocar a função de decisão. Sem bias, algumas fronteiras seriam excessivamente restritas.

## Aprendizado
Os pesos e biases são ajustados para reduzir uma função de perda.
