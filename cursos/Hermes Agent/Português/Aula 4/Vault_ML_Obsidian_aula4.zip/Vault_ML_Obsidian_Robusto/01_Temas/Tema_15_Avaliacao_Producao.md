# Avaliação e Produção

## Avaliação
O modelo deve ser avaliado em dados não usados no treinamento.

## Métrica correta
A métrica depende do problema e do custo dos erros.

## Produção
Um modelo pode piorar com mudanças nos dados ao longo do tempo.

## Monitoramento
É importante acompanhar desempenho, distribuição dos dados e possíveis mudanças de comportamento.

## Conceito-chave
Bom resultado no treino não garante bom resultado em produção.
