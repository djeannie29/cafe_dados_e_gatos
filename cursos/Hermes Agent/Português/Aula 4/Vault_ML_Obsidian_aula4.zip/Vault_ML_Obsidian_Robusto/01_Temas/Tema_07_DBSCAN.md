# DBSCAN

## O que é
Algoritmo de clustering baseado em densidade.

## Vantagens
- não exige definir o número de clusters previamente;
- pode encontrar grupos com formas irregulares;
- identifica pontos como ruído.

## Parâmetros principais
- epsilon: raio de vizinhança;
- min_samples: número mínimo de pontos para formar uma região densa.

## Limitações
Pode ter dificuldades quando os clusters possuem densidades muito diferentes.
