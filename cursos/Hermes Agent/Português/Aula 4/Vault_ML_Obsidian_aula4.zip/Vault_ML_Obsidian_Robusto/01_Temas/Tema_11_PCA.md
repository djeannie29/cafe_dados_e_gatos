# PCA

## Objetivo
Reduzir dimensionalidade preservando o máximo possível da variância dos dados.

## Como funciona
Cria novas combinações lineares chamadas componentes principais.

## Interpretação
95% de variância explicada não significa 95% de acurácia em uma tarefa de classificação.

## Cuidados
Escala pode influenciar fortemente o PCA quando variáveis possuem magnitudes diferentes.
