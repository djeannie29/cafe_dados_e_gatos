# Árvores e Ensembles

## Árvores de decisão
Dividem os dados em regras sucessivas.

## Bagging
Treina modelos em amostras diferentes e combina os resultados. Random Forest é um exemplo clássico.

## Boosting
Treina modelos sequencialmente, dando mais atenção aos erros anteriores.

## Diferença principal
Bagging busca reduzir variância combinando modelos em paralelo. Boosting busca corrigir erros progressivamente.
