# Classificação

## Objetivo
Prever classes ou categorias.

## Exemplos
- diagnóstico positivo ou negativo;
- churn ou permanência;
- imagem de gato ou cachorro.

## Métricas
Acurácia, precisão, recall, F1-score, matriz de confusão.

## Base desbalanceada
Acurácia pode ser enganosa. Um modelo que sempre prevê a classe majoritária pode parecer bom sem realmente resolver o problema.
