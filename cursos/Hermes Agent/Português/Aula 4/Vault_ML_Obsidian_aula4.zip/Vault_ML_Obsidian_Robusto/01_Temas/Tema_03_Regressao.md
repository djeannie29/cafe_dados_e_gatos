# Regressão

## Objetivo
Prever valores numéricos contínuos.

## Exemplos
- preço de casa;
- temperatura;
- demanda de produto.

## Métricas
MAE, RMSE e R² são comuns.

## Cuidados
R² alto não prova causalidade. Um bom ajuste não significa que uma variável causa outra.

## Relação com generalização
Um modelo pode ter ótimo desempenho no treino e pior desempenho em dados novos se estiver overfitting.
