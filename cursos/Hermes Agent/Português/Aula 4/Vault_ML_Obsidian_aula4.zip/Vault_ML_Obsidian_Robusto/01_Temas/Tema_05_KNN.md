# KNN

## O que é
K-Nearest Neighbors é um algoritmo baseado em proximidade entre exemplos.

## Como funciona
Para um novo ponto, calcula distâncias, encontra os k vizinhos mais próximos e usa esses vizinhos para decidir a saída.

## Papel de k
k pequeno pode tornar o modelo sensível a ruído. k grande pode suavizar demais a decisão.

## Escala
KNN é muito sensível à escala porque usa distância. Variáveis com amplitude maior podem dominar o cálculo.

## Erros comuns
- esquecer normalização;
- escolher k sem validação;
- supor que qualquer métrica de distância serve para qualquer problema.
