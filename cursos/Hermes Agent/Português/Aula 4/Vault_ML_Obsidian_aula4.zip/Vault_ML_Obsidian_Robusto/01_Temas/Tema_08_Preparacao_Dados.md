# Preparação de Dados

## Objetivo
Transformar dados brutos em dados adequados para treino e avaliação.

## Etapas comuns
- tratar ausentes;
- remover duplicatas quando apropriado;
- corrigir tipos;
- codificar categorias;
- normalizar ou padronizar;
- criar atributos.

## Relação com avaliação
Preparação mal feita pode gerar resultados enganosos. Se informações do conjunto de teste vazarem para o treino, ocorre data leakage.
