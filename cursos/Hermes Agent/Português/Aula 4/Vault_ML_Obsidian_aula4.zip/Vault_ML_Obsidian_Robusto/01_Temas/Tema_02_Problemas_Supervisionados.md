# Problemas Supervisionados

## Conceito
O modelo aprende a partir de exemplos com entradas e respostas conhecidas.

## Classificação
A saída pertence a uma categoria.

Exemplos:
- fraude ou não fraude;
- spam ou não spam;
- espécie de flor.

## Regressão
A saída é numérica contínua.

Exemplos:
- preço de imóvel;
- consumo de energia;
- tempo de entrega.

## Cuidados
É necessário definir corretamente a variável alvo e separar dados de treino e teste.
