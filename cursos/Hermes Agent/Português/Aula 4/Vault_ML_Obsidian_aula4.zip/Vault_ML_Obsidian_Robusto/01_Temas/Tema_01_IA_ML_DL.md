# IA, Machine Learning e Deep Learning

## Inteligência Artificial
Campo que reúne técnicas para criar sistemas capazes de executar tarefas associadas à inteligência.

## Machine Learning
Subárea da IA em que modelos aprendem padrões a partir de dados em vez de depender apenas de regras programadas manualmente.

## Deep Learning
Subárea de Machine Learning baseada em redes neurais com várias camadas.

## Relações
IA é o conjunto mais amplo. Machine Learning está dentro de IA. Deep Learning está dentro de Machine Learning.

## Erro comum
Tratar IA, Machine Learning e Deep Learning como sinônimos.
