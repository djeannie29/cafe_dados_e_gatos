# Vault de Machine Learning — Versão Robusta

Este Vault foi criado para testes de recuperação de conhecimento com Obsidian, OpenViking e Hindsight.

## Estrutura

- `00_Mapas`: mapas conceituais e pipelines.
- `01_Temas`: conteúdos principais de Machine Learning.
- `02_Conceitos`: conceitos transversais.
- `03_Comparacoes`: comparações entre técnicas e métricas.
- `04_Estudos_de_Caso`: exemplos aplicados.
- `05_Perguntas`: perguntas para testar recuperação, relações e síntese.

## Objetivo didático

O conteúdo foi organizado para permitir perguntas diretas, comparativas e relacionais. Algumas ideias aparecem em mais de uma nota de propósito, para testar recuperação semântica e síntese entre arquivos diferentes.
