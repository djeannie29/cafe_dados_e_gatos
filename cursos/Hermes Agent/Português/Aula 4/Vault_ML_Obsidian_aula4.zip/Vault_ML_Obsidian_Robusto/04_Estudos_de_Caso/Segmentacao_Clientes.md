# Estudo de Caso — Segmentação de Clientes

## Problema
Agrupar clientes por padrões de comportamento.

## Tipo
Clustering.

## Algoritmos
K-Means ou DBSCAN.

## Cuidado
Os grupos encontrados precisam ser interpretados com contexto de negócio. Cluster não é automaticamente um perfil real ou causal.
