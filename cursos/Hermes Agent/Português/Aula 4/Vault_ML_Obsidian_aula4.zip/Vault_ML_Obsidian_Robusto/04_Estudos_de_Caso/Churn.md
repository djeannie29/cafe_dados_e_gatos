# Estudo de Caso — Churn

## Problema
Prever quais clientes podem cancelar um serviço.

## Tipo
Classificação supervisionada.

## Desafio
Se poucos clientes cancelarem, a base pode ser desbalanceada.

## Métricas
Precisão, recall, F1-score e curva ROC podem ser mais úteis que acurácia isolada.
