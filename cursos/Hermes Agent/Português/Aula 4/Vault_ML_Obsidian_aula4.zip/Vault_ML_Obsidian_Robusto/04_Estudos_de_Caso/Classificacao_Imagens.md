# Estudo de Caso — Classificação de Imagens

## Problema
Classificar imagens em categorias.

## Abordagem
Redes neurais convolucionais ou arquiteturas modernas de visão.

## Cuidados
Separar corretamente treino, validação e teste. Evitar vazamento entre imagens muito semelhantes.
