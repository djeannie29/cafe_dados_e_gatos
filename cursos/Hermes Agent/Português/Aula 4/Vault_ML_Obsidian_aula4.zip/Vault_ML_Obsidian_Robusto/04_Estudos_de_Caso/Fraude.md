# Estudo de Caso — Detecção de Fraude

## Problema
Identificar transações fraudulentas.

## Tipo
Classificação.

## Desafio
Fraudes costumam ser raras.

## Consequência
Acurácia pode ser enganosa.

## Métrica crítica
Recall pode ser importante para reduzir fraudes não detectadas, mas precisão também importa para evitar bloquear transações legítimas.
