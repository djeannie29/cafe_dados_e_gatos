# Estudo de Caso — Preço de Imóveis

## Problema
Prever o preço de venda de imóveis.

## Tipo
Regressão supervisionada.

## Possíveis atributos
- área;
- número de quartos;
- localização;
- idade do imóvel.

## Métricas
MAE e RMSE.

## Cuidados
Outliers podem afetar RMSE. Variáveis de localização exigem representação adequada.
