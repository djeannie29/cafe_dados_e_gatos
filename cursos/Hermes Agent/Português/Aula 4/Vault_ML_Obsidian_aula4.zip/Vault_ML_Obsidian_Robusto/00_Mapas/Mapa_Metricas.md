# Mapa de Métricas

## Classificação

### Acurácia
Proporção total de previsões corretas.

### Precisão
Entre os casos previstos como positivos, quantos realmente eram positivos.

### Recall
Entre os positivos reais, quantos foram encontrados.

### F1-score
Equilibra precisão e recall por média harmônica.

## Regressão

### MAE
Erro absoluto médio. Mais fácil de interpretar e menos sensível a outliers que RMSE.

### RMSE
Penaliza erros grandes com mais intensidade.

### R²
Mede a proporção de variabilidade explicada pelo modelo em relação a uma referência simples. Não significa porcentagem de previsões corretas.
