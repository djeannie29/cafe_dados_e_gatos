# Mapa de Algoritmos por Tipo de Problema

## Classificação
- Regressão logística
- KNN
- Árvores de decisão
- Random Forest
- Gradient Boosting
- Redes neurais

## Regressão
- Regressão linear
- KNN Regressor
- Árvores de regressão
- Random Forest Regressor
- Gradient Boosting Regressor
- Redes neurais

## Clustering
- K-Means
- DBSCAN
- Hierárquico

## Redução de dimensionalidade
- PCA
- Autoencoders

## Sequências
- RNN
- LSTM
- GRU
- Transformers
