# Pipeline de Machine Learning

## Etapas principais

1. Definir o problema.
2. Identificar a variável alvo, quando existir.
3. Coletar e entender os dados.
4. Tratar dados ausentes e inconsistentes.
5. Fazer engenharia de atributos quando necessário.
6. Separar treino, validação e teste.
7. Normalizar ou padronizar quando o algoritmo for sensível à escala.
8. Treinar modelos candidatos.
9. Avaliar com métricas adequadas.
10. Comparar modelos.
11. Verificar overfitting e generalização.
12. Publicar e monitorar o modelo.

## Cuidados

Evitar data leakage. Transformações calculadas com base no conjunto completo podem vazar informação do teste para o treino.

A avaliação deve refletir o objetivo real. Acurácia pode ser inadequada em bases muito desbalanceadas.
