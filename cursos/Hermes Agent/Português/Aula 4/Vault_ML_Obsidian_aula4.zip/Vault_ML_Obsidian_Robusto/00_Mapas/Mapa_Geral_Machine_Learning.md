# Mapa Geral de Machine Learning

## Visão geral

Inteligência Artificial é um campo amplo. Machine Learning é uma subárea da IA em que sistemas aprendem padrões a partir de dados. Deep Learning é um subconjunto de Machine Learning baseado em redes neurais profundas.

## Tipos principais de aprendizado

### Supervisionado
Usa exemplos com rótulos.

Problemas comuns:
- classificação;
- regressão.

### Não supervisionado
Trabalha com dados sem rótulos explícitos.

Problemas comuns:
- clustering;
- redução de dimensionalidade;
- detecção de padrões.

### Aprendizado por reforço
Um agente aprende por interação com um ambiente e recebe recompensas ou penalidades.

## Relações importantes

- preparação de dados influencia avaliação;
- escala afeta algoritmos baseados em distância;
- validação ajuda a estimar generalização;
- regularização ajuda a reduzir overfitting;
- a melhor métrica depende do custo dos erros;
- o melhor algoritmo depende do problema e dos dados.
