# Perguntas de Relação

- Por que KNN e K-Means são sensíveis à escala, embora resolvam problemas diferentes?
- Qual é a relação entre overfitting, validação e regularização?
- Como data leakage pode produzir uma avaliação enganosa?
- Como generalização se relaciona com treino, validação e produção?
- Qual é a relação entre limiar de decisão, precisão e recall?
