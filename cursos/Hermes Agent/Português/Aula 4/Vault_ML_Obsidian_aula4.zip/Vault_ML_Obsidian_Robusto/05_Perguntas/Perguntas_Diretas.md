# Perguntas Diretas

- Qual é a diferença entre IA, Machine Learning e Deep Learning?
- O que caracteriza um problema de regressão?
- O que caracteriza um problema de classificação?
- Qual é o papel de k no KNN?
- O que é uma época em redes neurais?
- O que o bias faz em um neurônio?
- O que é data leakage?
