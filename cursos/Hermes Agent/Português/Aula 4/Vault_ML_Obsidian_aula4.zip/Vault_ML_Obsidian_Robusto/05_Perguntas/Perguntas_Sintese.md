# Perguntas de Síntese

- Descreva um pipeline completo de Machine Learning.
- Explique como um modelo pode ir bem no treino e falhar em produção.
- Monte um mapa relacionando IA, Machine Learning, Redes Neurais, Deep Learning e Transformers.
- Explique por que o melhor modelo depende do problema, da métrica e do custo dos erros.
- Quais conceitos aparecem repetidamente ao longo deste Vault?
