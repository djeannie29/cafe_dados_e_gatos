# Perguntas de Comparação

- Compare regressão e classificação.
- Compare bagging e boosting.
- Compare K-Means e DBSCAN.
- Compare RNN, LSTM/GRU e Transformer.
- Compare MAE e RMSE.
- Compare precisão e recall.
