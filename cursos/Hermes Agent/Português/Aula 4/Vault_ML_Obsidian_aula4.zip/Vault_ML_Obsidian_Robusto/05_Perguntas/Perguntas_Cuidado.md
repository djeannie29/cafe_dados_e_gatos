# Perguntas que Exigem Cuidado

- R² de 0,90 significa 90% de previsões corretas?
- Acurácia de 99% garante um bom classificador?
- PCA com 95% de variância explicada garante 95% de acurácia?
- Um cluster é automaticamente um perfil real?
- Um coeficiente de regressão prova causalidade?
