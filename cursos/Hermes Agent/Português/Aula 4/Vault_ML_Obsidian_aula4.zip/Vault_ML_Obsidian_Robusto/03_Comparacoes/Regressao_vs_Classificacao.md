# Regressão vs Classificação

## Regressão
Prevê valores contínuos.

## Classificação
Prevê categorias.

## Exemplo
Preço de casa: regressão.
Faixa de risco baixo/médio/alto: classificação.

## Avaliação
As métricas são diferentes porque o tipo de saída também é diferente.
