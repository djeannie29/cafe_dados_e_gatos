# RNN vs LSTM/GRU vs Transformer

## RNN
Recorrência simples e estado sequencial.

## LSTM/GRU
Mecanismos de memória para dependências mais longas.

## Transformer
Atenção e processamento mais paralelizável.

## Relação
Todos podem trabalhar com sequências, mas usam arquiteturas diferentes para representar dependências.
