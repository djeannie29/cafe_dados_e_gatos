# KNN vs K-Means

## KNN
Supervisionado. Usa rótulos conhecidos e vizinhos próximos para prever uma saída.

## K-Means
Não supervisionado. Agrupa pontos em clusters usando centróides.

## Semelhança importante
Os dois são sensíveis à escala porque dependem de distância.

## Diferença central
KNN prevê uma resposta a partir de exemplos conhecidos. K-Means descobre grupos sem rótulos.
