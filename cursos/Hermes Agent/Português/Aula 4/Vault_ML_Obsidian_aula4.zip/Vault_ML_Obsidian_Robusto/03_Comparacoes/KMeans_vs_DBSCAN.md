# K-Means vs DBSCAN

## K-Means
- exige k;
- usa centróides;
- favorece clusters compactos.

## DBSCAN
- usa densidade;
- não exige número de clusters;
- identifica ruído;
- pode encontrar formas irregulares.
