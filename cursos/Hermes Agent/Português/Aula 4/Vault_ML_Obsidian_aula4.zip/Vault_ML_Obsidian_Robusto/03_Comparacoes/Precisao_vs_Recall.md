# Precisão vs Recall

Precisão responde: entre os positivos previstos, quantos estavam corretos?

Recall responde: entre os positivos reais, quantos foram encontrados?

A prioridade depende do custo de falsos positivos e falsos negativos.
