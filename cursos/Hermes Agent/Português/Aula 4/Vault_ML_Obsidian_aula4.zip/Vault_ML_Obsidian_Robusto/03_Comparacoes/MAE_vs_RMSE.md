# MAE vs RMSE

MAE trata erros de forma linear. RMSE enfatiza erros grandes.

Use MAE quando quiser uma medida mais robusta a valores extremos. Use RMSE quando grandes erros forem especialmente custosos.
