# Bagging vs Boosting

## Bagging
Treina vários modelos de forma relativamente independente e combina as respostas.

## Boosting
Treina modelos em sequência, tentando corrigir erros anteriores.

## Objetivo típico
Bagging ajuda a reduzir variância. Boosting pode reduzir viés e melhorar ajuste de forma progressiva.
