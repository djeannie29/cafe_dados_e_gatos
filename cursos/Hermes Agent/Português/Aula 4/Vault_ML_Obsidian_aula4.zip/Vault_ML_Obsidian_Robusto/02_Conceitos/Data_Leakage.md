# Data Leakage

Data leakage ocorre quando informações que não deveriam estar disponíveis no treinamento acabam influenciando o modelo.

## Exemplo
Padronizar os dados usando média e desvio calculados com o conjunto completo antes da divisão entre treino e teste.

## Consequência
Resultados de avaliação artificialmente otimistas.
