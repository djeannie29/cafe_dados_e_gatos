# Overfitting

Overfitting acontece quando o modelo aprende excessivamente o conjunto de treino.

## Sintoma clássico
Treino muito bom e validação pior.

## Redução
- regularização;
- validação cruzada;
- early stopping;
- mais dados;
- simplificação do modelo.
