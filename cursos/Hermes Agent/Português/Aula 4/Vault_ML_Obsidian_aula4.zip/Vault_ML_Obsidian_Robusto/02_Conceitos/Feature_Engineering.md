# Feature Engineering

Feature engineering é o processo de criar, transformar ou selecionar atributos úteis para o modelo.

## Exemplos
- extrair dia da semana de uma data;
- combinar variáveis;
- criar razões;
- transformar escalas;
- codificar categorias.

## Cuidado
A transformação deve ser definida sem usar informação indevida do conjunto de teste.
