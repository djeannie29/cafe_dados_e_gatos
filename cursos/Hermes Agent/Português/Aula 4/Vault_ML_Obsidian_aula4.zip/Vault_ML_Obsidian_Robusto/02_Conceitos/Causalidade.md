# Causalidade

Correlação e capacidade preditiva não provam causalidade.

Um modelo pode usar uma variável para prever outra sem que exista relação causal direta entre elas.

Para inferência causal são necessárias hipóteses e desenhos de estudo adicionais.
