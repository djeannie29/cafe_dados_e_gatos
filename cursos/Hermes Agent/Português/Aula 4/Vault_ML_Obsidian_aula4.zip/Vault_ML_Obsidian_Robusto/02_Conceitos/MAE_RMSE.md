# MAE e RMSE

## MAE
Média dos erros absolutos. Mantém a unidade da variável alvo.

## RMSE
Raiz da média dos erros quadráticos. Penaliza mais fortemente erros grandes.

## Escolha
MAE pode ser preferível quando grandes erros não devem dominar a avaliação. RMSE pode ser útil quando erros grandes são especialmente indesejáveis.
