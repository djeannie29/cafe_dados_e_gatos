# Generalização

Generalização é a capacidade do modelo de funcionar bem em dados novos.

## Relações
- overfitting reduz generalização;
- validação estima generalização;
- regularização pode melhorar generalização;
- produção testa generalização em condições reais.
