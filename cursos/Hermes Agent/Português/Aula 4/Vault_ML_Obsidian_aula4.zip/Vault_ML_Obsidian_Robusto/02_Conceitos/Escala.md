# Escala

Algoritmos baseados em distância são sensíveis à escala.

## Exemplos
- KNN;
- K-Means;
- PCA em muitos cenários.

## Por quê
Uma variável com valores muito maiores pode dominar medidas de distância ou variância.

## Estratégias
- normalização;
- padronização.
