# Precisão e Recall

## Precisão
Entre os casos previstos como positivos, quantos eram realmente positivos.

## Recall
Entre os positivos reais, quantos foram encontrados.

## Trade-off
Alterar o limiar de decisão pode aumentar uma métrica e reduzir a outra.

## Exemplo
Em triagem médica, recall pode ser muito importante para reduzir falsos negativos.
