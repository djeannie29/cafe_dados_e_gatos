# Regularização

Regularização adiciona restrições ou penalidades para reduzir complexidade excessiva.

## Objetivo
Melhorar generalização e reduzir overfitting.

## Exemplos
- L1;
- L2;
- dropout em redes neurais.
