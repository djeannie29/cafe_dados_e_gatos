# Validação Cruzada

Validação cruzada divide os dados em múltiplas partes para repetir treino e avaliação em diferentes subconjuntos.

## Objetivo
Obter uma estimativa mais robusta do desempenho e ajudar na escolha de hiperparâmetros.

## Relação
É muito usada para escolher k no KNN, parâmetros de regularização e outras configurações.
