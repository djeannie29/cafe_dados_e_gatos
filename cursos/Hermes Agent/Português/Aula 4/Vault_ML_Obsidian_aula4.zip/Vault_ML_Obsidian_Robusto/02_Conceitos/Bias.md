# Bias

## Em redes neurais
Bias é um parâmetro adicional somado à combinação ponderada das entradas.

## Em aprendizado estatístico
Bias também pode significar erro sistemático de um modelo muito simples.

## Cuidado
Os dois sentidos são relacionados ao termo "bias", mas não são exatamente a mesma coisa.
