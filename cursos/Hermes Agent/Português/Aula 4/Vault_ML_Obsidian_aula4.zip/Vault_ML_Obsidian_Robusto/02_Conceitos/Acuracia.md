# Acurácia

Acurácia é a proporção de previsões corretas entre todas as previsões.

## Limitação
Em bases desbalanceadas, pode esconder desempenho ruim na classe minoritária.

Exemplo: se 99% dos casos forem negativos, um modelo que sempre diz "negativo" terá 99% de acurácia sem identificar nenhum positivo.
