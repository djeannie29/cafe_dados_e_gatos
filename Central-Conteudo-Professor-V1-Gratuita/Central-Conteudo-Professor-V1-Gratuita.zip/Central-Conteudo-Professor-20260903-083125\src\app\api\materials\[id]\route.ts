import { NextResponse } from "next/server";
import { rm } from "node:fs/promises";
import { db, ensureSchema, hasDatabase } from "@/lib/db";
import { materialStoragePath } from "@/lib/storage";

const LOCAL_USER = "local-professor";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!hasDatabase()) return NextResponse.json({ error: "Armazenamento local do navegador em uso." }, { status: 503 });
  const { id } = await context.params; const { content, title } = await request.json(); await ensureSchema();
  const rows = await db()`UPDATE materials SET content = COALESCE(${content ?? null}, content), title = COALESCE(${title ?? null}, title), updated_at = now() WHERE id = ${id} AND user_id = ${LOCAL_USER} RETURNING id`;
  return rows.length ? NextResponse.json({ ok: true }) : NextResponse.json({ error: "Material não encontrado." }, { status: 404 });
}

export async function DELETE(_: Request, context: { params: Promise<{ id: string }> }) {
  if (!hasDatabase()) return NextResponse.json({ error: "Armazenamento local do navegador em uso." }, { status: 503 });
  const { id } = await context.params; await ensureSchema();
  const rows = await db()`DELETE FROM materials WHERE id = ${id} AND user_id = ${LOCAL_USER} RETURNING id`;
  if (rows.length) await rm(materialStoragePath(id), { recursive: true, force: true });
  return rows.length ? NextResponse.json({ ok: true }) : NextResponse.json({ error: "Material não encontrado." }, { status: 404 });
}
