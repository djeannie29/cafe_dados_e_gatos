export const sourceTypes = [
  ["multiple", "Vários arquivos"], ["text", "Texto colado"], ["pdf", "PDF"],
  ["docx", "Word (.docx)"], ["pptx", "PowerPoint (.pptx)"], ["image", "Imagem com texto"],
  ["markdown", "Markdown (.md)"], ["transcription", "Transcrição (.txt/.srt/.vtt)"],
] as const;

export const outputTypes = [
  ["all", "Todos os materiais"], ["lesson_plan", "Plano de aula"],
  ["summary", "Resumo estruturado"], ["learning_objectives", "Objetivos de aprendizagem"],
  ["class_material", "Material de aula"], ["teacher_expository", "Roteiro expositivo para o professor"],
  ["presentation", "Apresentação para os alunos (PowerPoint)"],
  ["exercises", "Exercícios para alunos"], ["assessment", "Questões avaliativas completas"],
  ["true_false", "Questões verdadeiro ou falso"], ["multiple_choice", "Questões de múltipla escolha"],
  ["discursive", "Questões discursivas"], ["answer_key", "Gabarito (automático com exercícios)"],
  ["lesson_checklist", "Checklist da aula"],
] as const;

export const educationLevels = [
  ["early_childhood", "Educação Infantil"], ["fundamental_1", "Ensino Fundamental - anos iniciais"],
  ["fundamental_2", "Ensino Fundamental - anos finais"], ["high_school", "Ensino Médio"],
  ["higher_education", "Ensino Superior"], ["professional", "Educação profissional"],
] as const;

export const pedagogicalModels = [
  ["active_learning", "Aprendizagem ativa"], ["problem_based", "Aprendizagem baseada em problemas"],
  ["project_based", "Aprendizagem baseada em projetos"], ["traditional", "Aula expositiva estruturada"],
  ["flipped_classroom", "Sala de aula invertida"],
] as const;

export const explanationStyles = [["clear", "Clara e objetiva"], ["accessible", "Simples e acessível"], ["detailed", "Detalhada"], ["dialogic", "Dialógica e reflexiva"]] as const;
export const responseLengths = [["short", "Curta"], ["medium", "Média"], ["long", "Longa"]] as const;
export const languages = [["pt-BR", "Português (Brasil)"], ["en", "Inglês"], ["es", "Espanhol"]] as const;

export const aiProviders = [
  ["simulated", "Demonstração local", "simulado-professor", ""],
  ["openai", "OpenAI", "gpt-5.1", "https://api.openai.com/v1"],
  ["openrouter", "OpenRouter", "openrouter/free", "https://openrouter.ai/api/v1"],
  ["anthropic", "Anthropic — Claude Opus", "claude-opus-4-8", "https://api.anthropic.com/v1"],
  ["minimax", "MiniMax", "MiniMax-M3", "https://api.minimax.io/v1"],
  ["ollama", "Ollama — Gemma Cloud", "gemma4:cloud", "http://host.docker.internal:11434/v1"],
  ["compatible", "API compatível com OpenAI", "", ""],
] as const;
