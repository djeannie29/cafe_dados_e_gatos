import { NextResponse } from "next/server";
import { db, ensureSchema, hasDatabase } from "@/lib/db";

const LOCAL_USER = "local-professor";

export async function GET() {
  if (!hasDatabase()) return NextResponse.json({ storage: "browser", materials: [] }, { status: 503 });
  await ensureSchema();
  const rows = await db()`SELECT id, title, audience, teacher_name AS "teacherName", source_type AS "sourceType", output_types AS "outputTypes", education_level AS "educationLevel", pedagogical_model AS "pedagogicalModel", content, model, status, created_at AS "createdAt" FROM materials WHERE user_id = ${LOCAL_USER} ORDER BY created_at DESC`;
  const images = await db()<Array<{ id: string; materialId: string; marker: string; filename: string; sourceName: string; context: string; width: number; height: number }>>`SELECT i.id, i.material_id AS "materialId", i.marker, i.original_name AS filename, i.source_name AS "sourceName", i.context, i.width, i.height FROM material_images i JOIN materials m ON m.id = i.material_id WHERE m.user_id = ${LOCAL_USER} ORDER BY i.sort_order`;
  const byMaterial = new Map<string, Array<Record<string, unknown>>>();
  for (const image of images) {
    const list = byMaterial.get(image.materialId) || [];
    list.push({ ...image, url: `/api/images/${image.id}` });
    byMaterial.set(image.materialId, list);
  }
  return NextResponse.json({ storage: "database", materials: rows.map((row) => ({ ...row, images: byMaterial.get(String(row.id)) || [] })) });
}

export async function POST(request: Request) {
  if (!hasDatabase()) return NextResponse.json({ error: "Armazenamento local do navegador em uso." }, { status: 503 });
  const item = await request.json(); await ensureSchema();
  await db()`INSERT INTO materials (id, user_id, title, audience, teacher_name, source_type, output_types, education_level, pedagogical_model, content, model, status, created_at) VALUES (${item.id}, ${LOCAL_USER}, ${item.title}, ${item.audience}, ${item.teacherName || ""}, ${item.sourceType}, ${db().json(item.outputTypes)}, ${item.educationLevel}, ${item.pedagogicalModel}, ${item.content}, ${item.model}, ${item.status || "generated"}, ${new Date(item.createdAt)})`;
  return NextResponse.json({ material: item }, { status: 201 });
}
