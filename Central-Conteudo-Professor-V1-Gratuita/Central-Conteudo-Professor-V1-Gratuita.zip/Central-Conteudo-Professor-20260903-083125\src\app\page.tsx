import { ProfessorApp } from "@/components/ProfessorApp";

export default function Home() {
  return <ProfessorApp />;
}
