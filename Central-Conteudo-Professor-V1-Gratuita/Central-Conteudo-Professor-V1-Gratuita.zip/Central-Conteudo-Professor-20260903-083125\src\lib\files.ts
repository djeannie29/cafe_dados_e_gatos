export type MaterialImage = { id: string; marker: string; url: string; filename?: string; sourceName: string; context: string; width: number; height: number };
export type ExtractedImage = Omit<MaterialImage, "id" | "url"> & { file: File };
export type ExtractedFiles = { text: string; images: ExtractedImage[] };

const supportedImage = /\.(png|jpe?g|gif|bmp)$/i;

function imageMime(name: string) {
  const extension = name.split(".").pop()?.toLowerCase();
  return extension === "png" ? "image/png" : extension === "gif" ? "image/gif" : extension === "bmp" ? "image/bmp" : extension === "jpg" || extension === "jpeg" ? "image/jpeg" : "";
}

async function imageDimensions(file: Blob) {
  return new Promise<{ width: number; height: number }>((resolve) => {
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => { resolve({ width: image.naturalWidth, height: image.naturalHeight }); URL.revokeObjectURL(url); };
    image.onerror = () => { resolve({ width: 0, height: 0 }); URL.revokeObjectURL(url); };
    image.src = url;
  });
}

function relationships(xml: string) {
  const result = new Map<string, string>();
  for (const match of xml.matchAll(/<Relationship\b[^>]*\bId="([^"]+)"[^>]*\bTarget="([^"]+)"[^>]*\/?\s*>/g)) result.set(match[1], match[2]);
  return result;
}

async function zipImage(zip: import("jszip"), path: string, sourceName: string, context: string, originalName?: string) {
  const entry = zip.file(path);
  const name = originalName || path.split("/").pop() || "imagem.png";
  const mime = imageMime(name);
  if (!entry || !mime || !supportedImage.test(name)) return null;
  const file = new File([await entry.async("arraybuffer")], name, { type: mime });
  const size = await imageDimensions(file);
  if (!size.width || !size.height || size.width < 120 || size.height < 90 || size.width * size.height < 30000) return null;
  return { file, sourceName, context: plainText(context).slice(0, 1200), width: size.width, height: size.height };
}

export async function extractFiles(files: File[], onProgress?: (message: string) => void): Promise<ExtractedFiles> {
  const sections: string[] = [];
  const extractedImages: Array<Omit<ExtractedImage, "marker">> = [];
  for (const file of files) {
    const name = file.name.toLowerCase();
    onProgress?.(`Lendo ${file.name}...`);
    let text = "";
    if (/\.(txt|md|markdown|srt|vtt)$/.test(name)) {
      text = await file.text();
    } else if (name.endsWith(".docx")) {
      const mammoth = await import("mammoth/mammoth.browser");
      const buffer = await file.arrayBuffer();
      text = (await mammoth.extractRawText({ arrayBuffer: buffer })).value;
      const JSZip = (await import("jszip")).default;
      const zip = await JSZip.loadAsync(buffer);
      const documentXml = await zip.file("word/document.xml")?.async("text") || "";
      const relXml = await zip.file("word/_rels/document.xml.rels")?.async("text") || "";
      const rels = relationships(relXml);
      const seen = new Set<string>();
      for (const paragraph of documentXml.matchAll(/<w:p\b[\s\S]*?<\/w:p>/g)) {
        const paragraphXml = paragraph[0];
        const context = [...paragraphXml.matchAll(/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>/g)].map((match) => decodeXml(match[1])).join(" ");
        for (const embed of paragraphXml.matchAll(/r:embed="([^"]+)"/g)) {
          const target = rels.get(embed[1]);
          if (!target) continue;
          const mediaPath = `word/${target.replace(/^\.\.\//, "")}`.replace(/\\/g, "/");
          if (seen.has(mediaPath)) continue;
          seen.add(mediaPath);
          const image = await zipImage(zip, mediaPath, file.name, context || text.slice(0, 500));
          if (image) extractedImages.push(image);
        }
      }
    } else if (name.endsWith(".pptx")) {
      const JSZip = (await import("jszip")).default;
      const zip = await JSZip.loadAsync(await file.arrayBuffer());
      const slides = Object.values(zip.files).filter((entry) => /^ppt\/slides\/slide\d+\.xml$/.test(entry.name));
      const content: string[] = [];
      let lastSlideContext = "";
      for (const slide of slides.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }))) {
        const xml = await slide.async("text");
        const slideText = [...xml.matchAll(/<a:t>([\s\S]*?)<\/a:t>/g)].map((match) => decodeXml(match[1])).join(" ");
        content.push(slideText);
        const slideNumber = slide.name.match(/slide(\d+)\.xml$/)?.[1] || "";
        const imageContext = slideText.trim() || (lastSlideContext ? `Imagem de apoio após: ${lastSlideContext}` : `Slide ${slideNumber}`);
        const relXml = await zip.file(`ppt/slides/_rels/slide${slideNumber}.xml.rels`)?.async("text") || "";
        const rels = relationships(relXml);
        for (const embed of xml.matchAll(/r:embed="([^"]+)"/g)) {
          const target = rels.get(embed[1]);
          if (!target) continue;
          const mediaPath = `ppt/slides/${target}`.split("/").reduce<string[]>((parts, part) => part === ".." ? (parts.pop(), parts) : part === "." ? parts : [...parts, part], []).join("/");
          const image = await zipImage(zip, mediaPath, file.name, `Slide ${slideNumber}: ${imageContext}`);
          if (image) extractedImages.push(image);
        }
        if (slideText.trim()) lastSlideContext = slideText.trim().slice(0, 800);
      }
      text = content.join("\n\n");
    } else if (name.endsWith(".pdf")) {
      const pdfjs = await import("pdfjs-dist");
      pdfjs.GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url).toString();
      const pdf = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
      const pages: string[] = [];
      for (let index = 1; index <= pdf.numPages; index += 1) {
        const page = await pdf.getPage(index);
        const content = await page.getTextContent();
        pages.push(content.items.map((item) => "str" in item ? item.str : "").join(" "));
      }
      text = pages.join("\n\n");
    } else if (/\.(png|jpe?g|webp|tiff?)$/.test(name)) {
      onProgress?.(`Reconhecendo o texto de ${file.name}...`);
      const Tesseract = await import("tesseract.js");
      text = (await Tesseract.recognize(file, "por")).data.text;
      if (supportedImage.test(name) && imageMime(name)) {
        const size = await imageDimensions(file);
        extractedImages.push({ file, sourceName: file.name, context: text.trim().slice(0, 1200) || `Imagem enviada: ${file.name}`, width: size.width, height: size.height });
      }
    } else {
      text = `Arquivo anexado: ${file.name}`;
    }
    sections.push(`### Fonte: ${file.name}\n\n${text.trim()}`);
  }
  const images = extractedImages.slice(0, 30).map((image, index) => ({ ...image, marker: `IMAGEM_${index + 1}` }));
  return { text: sections.join("\n\n---\n\n"), images };
}

function decodeXml(value: string) {
  return value.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&apos;/g, "'");
}

function downloadBlob(content: BlobPart, filename: string, type: string) {
  const link = document.createElement("a");
  link.href = URL.createObjectURL(new Blob([content], { type }));
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

function cleanExportContent(content: string) {
  return content
    .replace(/<think>[\s\S]*?<\/think>\s*/gi, "")
    .replace(/<\/?think>/gi, "")
    .replace(/^```(?:markdown)?\s*$/gim, "")
    .trim();
}

function withoutImageMarkers(content: string) {
  return content
    .replace(/^\s*\[?IMAGEM_\d+\]?\s*$/gim, "")
    .replace(/\[?IMAGEM_\d+\]?/gi, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function answerKeyLast(content: string) {
  const match = /^##\s+gabarito\b/im.exec(content);
  if (match?.index === undefined) return content;
  const remainder = content.slice(match.index);
  const nextSection = /^##\s+/gm;
  nextSection.lastIndex = match[0].length;
  const next = nextSection.exec(remainder);
  if (!next) return content;
  const answerKey = remainder.slice(0, next.index).trim();
  const after = remainder.slice(next.index).trim();
  return `${content.slice(0, match.index).trimEnd()}\n\n${after}\n\n${answerKey}`.trim();
}

function plainText(value: string) {
  return value
    .replace(/^#{1,6}\s+/, "")
    .replace(/^\s*(?:[-*+]\s+|\d+[.)]\s+)/, "")
    .replace(/\*\*(.*?)\*\*/g, "$1")
    .replace(/__(.*?)__/g, "$1")
    .replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/^>\s*/, "")
    .replace(/\s+/g, " ")
    .trim();
}

function normalized(value: string) {
  return plainText(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

function isExerciseHeading(value: string) {
  return /\b(atividades?|exercicios?|questoes?|verdadeiro|falso|multipla escolha|discursivas?)\b/.test(normalized(value));
}

function wordRuns(value: string, TextRun: typeof import("docx").TextRun) {
  const clean = value.replace(/^>\s*/, "");
  const runs: InstanceType<typeof TextRun>[] = [];
  let cursor = 0;
  for (const match of clean.matchAll(/\*\*(.*?)\*\*/g)) {
    const index = match.index ?? 0;
    if (index > cursor) runs.push(new TextRun(clean.slice(cursor, index)));
    runs.push(new TextRun({ text: match[1], bold: true }));
    cursor = index + match[0].length;
  }
  if (cursor < clean.length) runs.push(new TextRun(clean.slice(cursor)));
  return runs.length ? runs : [new TextRun(plainText(clean))];
}

type StudentSlide = { title: string; bullets: string[]; imageMarkers: string[] };

function markersIn(value: string) {
  return [...value.matchAll(/\[?(IMAGEM_\d+)\]?/gi)].map((match) => match[1].toUpperCase());
}

function usefulTokens(value: string) {
  const ignored = new Set(["para", "como", "uma", "uns", "das", "dos", "que", "com", "sem", "fonte", "slide", "imagem", "arquivo", "documento"]);
  return normalized(value).split(/\W+/).filter((word) => word.length > 3 && !ignored.has(word));
}

function imageScore(image: MaterialImage, value: string) {
  const haystack = normalized(value);
  return usefulTokens(`${image.context} ${image.sourceName}`).reduce((score, token) => score + (haystack.includes(token) ? 1 : 0), 0);
}

type LoadedImage = MaterialImage & { data: Uint8Array; dataUrl: string; type: "jpg" | "png" | "gif" | "bmp" };

async function loadMaterialImages(images: MaterialImage[]) {
  const loaded: LoadedImage[] = [];
  for (const image of images.slice(0, 30)) {
    try {
      const response = await fetch(image.url);
      if (!response.ok) continue;
      const contentType = response.headers.get("content-type") || "image/png";
      const type = contentType.includes("jpeg") ? "jpg" : contentType.includes("gif") ? "gif" : contentType.includes("bmp") ? "bmp" : "png";
      const buffer = await response.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = "";
      for (let offset = 0; offset < bytes.length; offset += 0x8000) binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
      loaded.push({ ...image, data: bytes, dataUrl: `data:${contentType};base64,${btoa(binary)}`, type });
    } catch { /* Uma imagem ausente não deve impedir a exportação do conteúdo. */ }
  }
  return loaded;
}

function containedSize(width: number, height: number, maxWidth: number, maxHeight: number) {
  const safeWidth = width || maxWidth;
  const safeHeight = height || maxHeight;
  const scale = Math.min(maxWidth / safeWidth, maxHeight / safeHeight, 1);
  return { width: Math.round(safeWidth * scale), height: Math.round(safeHeight * scale) };
}

function compactBullet(value: string) {
  const text = plainText(value).replace(/^\|\s*|\s*\|$/g, "").replace(/\s*\|\s*/g, " — ").trim();
  return text.length > 165 ? `${text.slice(0, 162).trimEnd()}…` : text;
}

function supportingBullets(content: string, slideTitle: string) {
  const ignoredWords = new Set(["para", "como", "com", "uma", "das", "dos", "que", "vamos", "industrial", "revolucao", "hoje"]);
  const tokens = normalized(slideTitle).split(/\W+/).filter((word) => word.length > 3 && !ignoredWords.has(word));
  const groups: Array<{ title: string; body: string[] }> = [];
  let major = "";
  let group: { title: string; body: string[] } | null = null;
  for (const line of content.split(/\r?\n/)) {
    const majorHeading = line.match(/^##\s+(.*)$/);
    if (majorHeading) {
      major = normalized(majorHeading[1]);
      group = null;
      continue;
    }
    if (/plano de aula|gabarito|checklist|apresenta|exercicios|questoes discursivas/.test(major)) continue;
    const minorHeading = line.match(/^###\s+(.*)$/);
    if (minorHeading) {
      group = { title: plainText(minorHeading[1]), body: [] };
      groups.push(group);
      continue;
    }
    const text = compactBullet(line);
    if (group && text && !/^[-—| ]+$/.test(text) && !/^tempo:|^organiza/i.test(text)) group.body.push(text);
  }

  if (/vamos aprender/.test(normalized(slideTitle))) {
    const objectives: string[] = [];
    let inside = false;
    for (const line of content.split(/\r?\n/)) {
      if (/^##\s+.*objetivos/i.test(line)) { inside = true; continue; }
      if (inside && /^##\s+/.test(line)) break;
      if (inside && /^\s*\d+[.)]\s+/.test(line)) objectives.push(compactBullet(line));
    }
    return objectives.slice(0, 5);
  }

  if (/cercamentos/.test(normalized(slideTitle))) {
    return groups.flatMap((candidate) => candidate.body).filter((line) => /cercamento|campones|\bcampo\b|\bcidades?\b/i.test(line)).slice(0, 2);
  }
  if (/james watt/.test(normalized(slideTitle))) {
    return groups.flatMap((candidate) => candidate.body).filter((line) => /james watt|m[aá]quina a vapor/i.test(line)).slice(0, 2);
  }
  if (/urbanizacao|alienacao/.test(normalized(slideTitle))) {
    return groups.flatMap((candidate) => candidate.body).filter((line) => /urbaniza|aliena|proletariado|burguesia/i.test(line)).slice(0, 4);
  }
  if (/aprendemos/.test(normalized(slideTitle))) {
    return groups.filter((candidate) => /o que foi|manufatura|nova sociedade|segunda revolucao/i.test(normalized(candidate.title))).flatMap((candidate) => candidate.body.slice(0, 1)).slice(0, 5);
  }

  const ranked = groups.map((candidate) => {
    const heading = normalized(candidate.title);
    const body = normalized(candidate.body.join(" "));
    const score = tokens.reduce((total, token) => total + (heading.includes(token) ? 3 : body.includes(token) ? 1 : 0), 0);
    return { ...candidate, score };
  }).filter((candidate) => candidate.score > 0).sort((a, b) => b.score - a.score || b.body.length - a.body.length);
  const best = ranked[0];
  if (!best) return [];
  return best.body.filter((line) => !/imagem|foto|ilustra|inserir|professor/i.test(line)).slice(0, 5);
}

function presentationSection(content: string) {
  const lines = content.split(/\r?\n/);
  const start = lines.findIndex((line) => /^##\s+.*apresenta/i.test(line));
  if (start < 0) return [];
  const result: string[] = [];
  for (let index = start + 1; index < lines.length; index += 1) {
    if (/^##\s+/.test(lines[index])) break;
    result.push(lines[index]);
  }
  return result;
}

function bibliographySlides(content: string): StudentSlide[] {
  const lines = content.split(/\r?\n/);
  const start = lines.findIndex((line) => /^##\s+refer[eê]ncias(?: bibliogr[aá]ficas)?\s*$/i.test(line.trim()));
  if (start < 0) return [];
  const references: string[] = [];
  for (let index = start + 1; index < lines.length; index += 1) {
    if (/^##\s+/.test(lines[index])) break;
    const reference = plainText(lines[index]);
    if (reference && !references.includes(reference)) references.push(reference);
  }
  const slides: StudentSlide[] = [];
  for (let index = 0; index < references.length; index += 4) {
    slides.push({
      title: index ? "Fontes e referências — continuação" : "Fontes e referências",
      bullets: references.slice(index, index + 4),
      imageMarkers: [],
    });
  }
  return slides;
}

function withoutPresentationSection(content: string) {
  const lines = content.split(/\r?\n/);
  const result: string[] = [];
  let skipping = false;
  for (const line of lines) {
    if (/^##\s+.*apresenta/i.test(line)) { skipping = true; continue; }
    if (skipping && /^##\s+/.test(line)) skipping = false;
    if (!skipping) result.push(line);
  }
  return result.join("\n").trim();
}

function parseStudentSlides(content: string, materialTitle: string): StudentSlide[] {
  const section = presentationSection(content);
  const slides: StudentSlide[] = [];
  let current: StudentSlide | null = null;

  for (const line of section) {
    const heading = line.match(/^###\s+(?:slide\s*\d+\s*[-—:]?\s*)?(.*)$/i);
    if (heading) {
      if (current?.title) slides.push(current);
      current = { title: plainText(heading[1]), bullets: [], imageMarkers: markersIn(line) };
      continue;
    }
    if (current && markersIn(line).length) {
      current.imageMarkers.push(...markersIn(line));
      continue;
    }
    if (current && /^\s*(?:[-*+]\s+|\d+[.)]\s+)/.test(line)) {
      const bullet = compactBullet(line);
      if (bullet) current.bullets.push(bullet);
    } else if (current && plainText(line)) {
      current.bullets.push(compactBullet(line));
    }
  }
  if (current?.title) slides.push(current);

  if (!slides.length) {
    for (const line of section.filter((item) => /^\s*\|/.test(item))) {
      const cells = line.split("|").slice(1, -1).map((cell) => plainText(cell));
      if (cells.length < 3 || !/^\d+$/.test(cells[0]) || /^-+$/.test(cells[1])) continue;
      const detail = cells[2]
        .replace(/^imagem\s+[^.]+\.?\s*/i, "")
        .replace(/^fotos?\s+[^.]+\.?\s*/i, "")
        .replace(/^tabela:\s*/i, "Compare: ")
        .trim();
      const isInstruction = /imagem|foto|mapa|linha do tempo|lista dos|resumo dos|ilustra|t[ií]tulo e nome|compara[cç][aã]o lado a lado/i.test(cells[2]);
      const bullets = isInstruction || !detail ? [] : [compactBullet(detail)];
      for (const supporting of supportingBullets(content, cells[1])) {
        if (bullets.length >= 5) break;
        if (!bullets.includes(supporting)) bullets.push(supporting);
      }
      slides.push({ title: cells[1], bullets, imageMarkers: markersIn(line) });
    }
  }

  if (!slides.length) {
    const lines = content.split(/\r?\n/);
    let fallback: StudentSlide | null = null;
    const blocked = /plano de aula|gabarito|checklist|resposta esperada|professor|material de aula|exercicio/;
    for (const line of lines) {
      const major = line.match(/^##\s+(.*)$/);
      if (major) {
        if (fallback?.title && fallback.bullets.length) slides.push(fallback);
        const title = plainText(major[1]);
        fallback = blocked.test(normalized(title)) ? null : { title, bullets: [], imageMarkers: [] };
      } else if (fallback && plainText(line) && !/^[-|]+$/.test(line.trim())) {
        fallback.bullets.push(compactBullet(line));
      }
    }
    if (fallback?.title && fallback.bullets.length) slides.push(fallback);
  }

  const deckTitle = normalized(materialTitle);
  const expanded: StudentSlide[] = [];
  for (const slide of slides) {
    const slideTitle = normalized(slide.title);
    if (!slide.title || deckTitle === slideTitle || deckTitle.includes(slideTitle) || slideTitle.includes(deckTitle) || /roteiro de slides/.test(slideTitle)) continue;
    const bullets = slide.bullets.filter(Boolean);
    if (!bullets.length) bullets.push("Observe, converse e registre as ideias principais deste tema.");
    for (let index = 0; index < bullets.length; index += 5) {
      expanded.push({ title: index ? `${slide.title} — continuação` : slide.title, bullets: bullets.slice(index, index + 5), imageMarkers: index ? [] : slide.imageMarkers });
    }
  }
  const sources = bibliographySlides(content);
  return [...expanded.slice(0, Math.max(0, 30 - sources.length)), ...sources].slice(0, 30);
}

export async function exportMaterial(title: string, content: string, format: "md" | "txt" | "docx" | "pptx", teacherName = "", images: MaterialImage[] = []) {
  const safe = title.trim().replace(/[^a-zA-Z0-9À-ÿ_-]+/g, "-").replace(/^-|-$/g, "") || "material";
  const cleanedContent = answerKeyLast(cleanExportContent(content));
  if (format === "md" || format === "txt") {
    downloadBlob(withoutImageMarkers(cleanedContent), `${safe}.${format}`, "text/plain;charset=utf-8");
    return;
  }
  const loadedImages = await loadMaterialImages(images);
  if (format === "docx") {
    const { AlignmentType, Document, Footer, HeadingLevel, ImageRun, Packer, PageNumber, Paragraph, TextRun } = await import("docx");
    const children: InstanceType<typeof Paragraph>[] = [];
    const wordLines = withoutPresentationSection(cleanedContent).split(/\r?\n/);
    const byMarker = new Map(loadedImages.map((image) => [image.marker.toUpperCase(), image]));
    const explicitlyUsed = new Set(markersIn(wordLines.join("\n")));
    const automaticAt = new Map<number, LoadedImage[]>();
    const automaticCandidates: Array<{ image: LoadedImage; index: number; score: number }> = [];
    for (const image of explicitlyUsed.size ? [] : loadedImages) {
      let best = { index: -1, score: 0 };
      wordLines.forEach((line, index) => {
        if (!plainText(line) || /gabarito|refer[eê]ncias|exerc[ií]cios?|avalia[cç][aã]o/i.test(normalized(line))) return;
        const score = imageScore(image, `${wordLines[index - 1] || ""} ${line} ${wordLines[index + 1] || ""}`);
        if (score > best.score) best = { index, score };
      });
      if (best.index >= 0 && best.score >= 2) automaticCandidates.push({ image, ...best });
    }
    for (const candidate of automaticCandidates.sort((a, b) => b.score - a.score).slice(0, 6)) automaticAt.set(candidate.index, [...(automaticAt.get(candidate.index) || []), candidate.image]);
    const added = new Set<string>();
    const pushImage = (image: LoadedImage) => {
      if (added.has(image.id)) return;
      added.add(image.id);
      const size = containedSize(image.width, image.height, 560, 340);
      children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 140, after: 60 }, keepNext: true, children: [new ImageRun({ type: image.type, data: image.data, transformation: size, altText: { title: image.sourceName || "Imagem do material", description: image.context || "Imagem relacionada ao conteúdo", name: image.marker } })] }));
      children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 140 }, children: [new TextRun({ text: image.context ? plainText(image.context).slice(0, 180) : `Imagem de ${image.sourceName}`, italics: true, color: "607476", size: 18 })] }));
    };
    let majorHeadingIsAlone = false;
    for (let lineIndex = 0; lineIndex < wordLines.length; lineIndex += 1) {
      const rawLine = wordLines[lineIndex];
      const line = rawLine.trimEnd();
      const explicitMarkers = markersIn(line);
      if (explicitMarkers.length && !plainText(line.replace(/\[?IMAGEM_\d+\]?/gi, ""))) {
        for (const marker of explicitMarkers) { const image = byMarker.get(marker); if (image) pushImage(image); }
        continue;
      }
      if (!line.trim() || /^-{2,}$/.test(line.trim())) {
        continue;
      }
      const heading = line.match(/^(#{1,6})\s+(.*)$/);
      if (heading) {
        const level = heading[1].length;
        const text = plainText(heading[2]);
        children.push(new Paragraph({
          text,
          heading: level === 1 ? HeadingLevel.TITLE : level === 2 ? HeadingLevel.HEADING_1 : HeadingLevel.HEADING_2,
          pageBreakBefore: level === 2 || (level >= 3 && isExerciseHeading(text) && !majorHeadingIsAlone),
          spacing: { before: 180, after: 120 },
        }));
        majorHeadingIsAlone = level === 2;
        for (const image of automaticAt.get(lineIndex) || []) pushImage(image);
        continue;
      }
      majorHeadingIsAlone = false;
      const bullet = line.match(/^\s*[-*+]\s+(.*)$/);
      const numbered = line.match(/^\s*(\d+)[.)]\s+(.*)$/);
      if (bullet) {
        children.push(new Paragraph({ children: wordRuns(bullet[1], TextRun), bullet: { level: 0 }, spacing: { after: 70 }, keepNext: false }));
      } else if (numbered) {
        children.push(new Paragraph({ children: wordRuns(`${numbered[1]}. ${numbered[2]}`, TextRun), spacing: { after: 70 }, indent: { left: 360, hanging: 240 } }));
      } else {
        children.push(new Paragraph({ children: wordRuns(line.replace(/\[?IMAGEM_\d+\]?/gi, ""), TextRun), spacing: { after: 100, line: 300 } }));
      }
      for (const marker of explicitMarkers) { const image = byMarker.get(marker); if (image) pushImage(image); }
      for (const image of automaticAt.get(lineIndex) || []) pushImage(image);
    }
    const blob = await Packer.toBlob(new Document({
      styles: {
        default: { document: { run: { font: "Aptos", size: 22, color: "26383B" } } },
        paragraphStyles: [
          { id: "Title", name: "Title", basedOn: "Normal", next: "Normal", run: { font: "Aptos Display", size: 42, bold: true, color: "155B55" }, paragraph: { spacing: { after: 280 }, alignment: AlignmentType.LEFT } },
          { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", run: { font: "Aptos Display", size: 32, bold: true, color: "176F69" }, paragraph: { spacing: { before: 240, after: 160 } } },
          { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", run: { font: "Aptos Display", size: 26, bold: true, color: "277FBA" }, paragraph: { spacing: { before: 180, after: 100 } } },
        ],
      },
      sections: [{
        properties: { page: { margin: { top: 900, right: 900, bottom: 900, left: 900 } } },
        children,
        footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "Central de Conteúdo com IA  •  ", color: "718184", size: 18 }), new TextRun({ children: [PageNumber.CURRENT], color: "718184", size: 18 })] })] }) },
      }],
    }));
    downloadBlob(blob, `${safe}.docx`, "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
    return;
  }
  const PptxGenJS = (await import("pptxgenjs")).default;
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_WIDE";
  pptx.author = teacherName.trim() || "Central de Conteúdo com IA";
  pptx.subject = "Apresentação didática para os alunos";
  pptx.title = title;
  pptx.company = "Central de Conteúdo com IA";
  pptx.theme = { headFontFace: "Aptos Display", bodyFontFace: "Aptos" };
  const shape = pptx.ShapeType;
  const cover = pptx.addSlide();
  cover.background = { color: "103B3A" };
  cover.addShape(shape.rect, { x: 0, y: 0, w: 0.25, h: 7.5, line: { color: "F0B44D", transparency: 100 }, fill: { color: "F0B44D" } });
  if (teacherName.trim()) cover.addText(`Professor(a): ${teacherName.trim()}`, { x: 0.9, y: 0.85, w: 8.5, h: 0.4, fontSize: 17, bold: true, color: "F0B44D", margin: 0 });
  cover.addText(title, { x: 0.9, y: 1.55, w: 10.9, h: 2.4, fontSize: 46, bold: true, color: "FFFFFF", breakLine: false, margin: 0.02, valign: "middle", fit: "shrink" });
  cover.addText("Vamos compreender, relacionar e conversar sobre este tema.", { x: 0.95, y: 4.45, w: 8.9, h: 0.65, fontSize: 23, color: "D6E8E4", margin: 0 });
  cover.addShape(shape.line, { x: 0.95, y: 5.55, w: 3.2, h: 0, line: { color: "F0B44D", width: 4 } });
  cover.addText("Central de Conteúdo com IA", { x: 0.95, y: 6.55, w: 4.2, h: 0.3, fontSize: 12, color: "9FC5C0", margin: 0 });

  const slides = parseStudentSlides(cleanedContent, title);
  const prepared = slides.length ? slides : [{ title: "Para começar", bullets: ["O que você já sabe sobre este tema?", "Que perguntas gostaria de responder durante a aula?"], imageMarkers: [] }];
  const presentationImages = new Map(loadedImages.map((image) => [image.marker.toUpperCase(), image]));
  const usedPresentationImages = new Set<string>();
  const hasExplicitPresentationImages = prepared.some((slide) => slide.imageMarkers.length);
  prepared.forEach((item, index) => {
    const slide = pptx.addSlide();
    const warm = index % 2 === 0;
    slide.background = { color: warm ? "F7F2E8" : "F2F7F6" };
    slide.addShape(shape.rect, { x: 0, y: 0, w: 13.333, h: 0.18, line: { color: warm ? "F0B44D" : "2B8C85", transparency: 100 }, fill: { color: warm ? "F0B44D" : "2B8C85" } });
    slide.addText(String(index + 1).padStart(2, "0"), { x: 0.72, y: 0.62, w: 0.72, h: 0.5, fontSize: 18, bold: true, color: "FFFFFF", align: "center", valign: "middle", margin: 0, fill: { color: "176F69" }, line: { color: "176F69" } });
    slide.addText(item.title, { x: 1.7, y: 0.55, w: 10.7, h: 0.85, fontSize: 30, bold: true, color: "103B3A", margin: 0, fit: "shrink" });
    slide.addShape(shape.line, { x: 1.7, y: 1.52, w: 2.0, h: 0, line: { color: warm ? "E39A2D" : "2B8C85", width: 3 } });
    let selectedImage = item.imageMarkers.map((marker) => presentationImages.get(marker)).find((image): image is LoadedImage => Boolean(image && !usedPresentationImages.has(image.id)));
    if (!selectedImage && !hasExplicitPresentationImages) {
      selectedImage = loadedImages
        .filter((image) => !usedPresentationImages.has(image.id))
        .map((image) => ({ image, score: imageScore(image, `${item.title} ${item.bullets.join(" ")}`) }))
        .filter((candidate) => candidate.score >= 2)
        .sort((a, b) => b.score - a.score)[0]?.image;
    }
    if (selectedImage) usedPresentationImages.add(selectedImage.id);
    const body = item.bullets.slice(0, 5).map((bullet) => ({ text: withoutImageMarkers(bullet), options: { bullet: { indent: 24 }, hanging: 5, breakLine: true, paraSpaceAfterPt: 18 } }));
    slide.addText(body, { x: 1.45, y: 1.95, w: selectedImage ? 5.65 : 10.7, h: 4.65, fontSize: 20, color: "26383B", breakLine: true, valign: "middle", margin: 0.08, fit: "shrink" });
    if (selectedImage) {
      slide.addShape(shape.roundRect, { x: 7.65, y: 1.82, w: 4.85, h: 4.85, line: { color: warm ? "E3C98C" : "A7CDC9", width: 1.2 }, fill: { color: "FFFFFF" }, shadow: { type: "outer", color: "68817E", opacity: 0.18, blur: 2, angle: 45 } });
      const ratio = (selectedImage.width || 1) / (selectedImage.height || 1);
      let imageWidth = 4.45; let imageHeight = imageWidth / ratio;
      if (imageHeight > 4.05) { imageHeight = 4.05; imageWidth = imageHeight * ratio; }
      slide.addImage({ data: selectedImage.dataUrl, x: 7.85 + (4.45 - imageWidth) / 2, y: 2.05 + (4.05 - imageHeight) / 2, w: imageWidth, h: imageHeight });
      slide.addText(selectedImage.sourceName, { x: 7.9, y: 6.27, w: 4.35, h: 0.22, fontSize: 9, italic: true, color: "6E807F", align: "center", margin: 0, fit: "shrink" });
    }
    slide.addText(title, { x: 0.75, y: 7.02, w: 9.7, h: 0.22, fontSize: 10, color: "6E807F", margin: 0 });
    slide.addText(`${index + 2}`, { x: 11.9, y: 6.96, w: 0.55, h: 0.25, fontSize: 11, bold: true, color: "176F69", align: "right", margin: 0 });
  });
  await pptx.writeFile({ fileName: `${safe}.pptx` });
}
