import { randomUUID } from "node:crypto";
import { mkdir, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { db, ensureSchema, hasDatabase } from "@/lib/db";
import { imageExtension, materialStoragePath } from "@/lib/storage";

const LOCAL_USER = "local-professor";
const MAX_IMAGE_SIZE = 10 * 1024 * 1024;
const MAX_IMAGES = 30;

type ImageMeta = { marker?: string; sourceName?: string; context?: string; width?: number; height?: number };

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!hasDatabase()) return NextResponse.json({ error: "Banco local não configurado." }, { status: 503 });
  const { id: materialId } = await context.params;
  await ensureSchema();
  const owner = await db()`SELECT id FROM materials WHERE id = ${materialId} AND user_id = ${LOCAL_USER}`;
  if (!owner.length) return NextResponse.json({ error: "Material não encontrado." }, { status: 404 });

  const form = await request.formData();
  let metadata: ImageMeta[] = [];
  try { metadata = JSON.parse(String(form.get("metadata") || "[]")); } catch { return NextResponse.json({ error: "Metadados de imagem inválidos." }, { status: 400 }); }
  const files = form.getAll("images").filter((item): item is File => item instanceof File).slice(0, MAX_IMAGES);
  if (!files.length) return NextResponse.json({ images: [] });
  const directory = materialStoragePath(materialId);
  await mkdir(directory, { recursive: true });
  const saved: Array<Record<string, unknown>> = [];

  try {
    for (let index = 0; index < files.length; index += 1) {
      const file = files[index];
      const extension = imageExtension(file.type);
      if (!extension || file.size > MAX_IMAGE_SIZE) continue;
      const imageId = randomUUID();
      const storedName = `${imageId}.${extension}`;
      await writeFile(path.join(/* turbopackIgnore: true */ directory, storedName), new Uint8Array(await file.arrayBuffer()), { flag: "wx" });
      const meta = metadata[index] || {};
      const marker = String(meta.marker || `IMAGEM_${index + 1}`).slice(0, 60);
      const sourceName = String(meta.sourceName || "").slice(0, 255);
      const imageContext = String(meta.context || "").slice(0, 2000);
      const width = Math.max(0, Math.round(Number(meta.width) || 0));
      const height = Math.max(0, Math.round(Number(meta.height) || 0));
      await db()`INSERT INTO material_images (id, material_id, marker, stored_name, original_name, mime_type, source_name, context, width, height, sort_order) VALUES (${imageId}, ${materialId}, ${marker}, ${storedName}, ${file.name.slice(0, 255)}, ${file.type}, ${sourceName}, ${imageContext}, ${width}, ${height}, ${index})`;
      saved.push({ id: imageId, marker, filename: file.name, sourceName, context: imageContext, width, height, url: `/api/images/${imageId}` });
    }
  } catch (error) {
    await db()`DELETE FROM material_images WHERE material_id = ${materialId}`;
    await rm(directory, { recursive: true, force: true });
    throw error;
  }
  return NextResponse.json({ images: saved }, { status: 201 });
}
