import { NextResponse } from "next/server";
import { exercisePromptInstruction, filterUnrequestedExerciseSections } from "@/lib/exercise-request";

type GenerationRequest = {
  title: string;
  audience: string;
  teacherName?: string;
  sourceText: string;
  outputLabels: string[];
  outputTypes?: string[];
  educationLevel: string;
  pedagogicalModel: string;
  explanationStyle?: string;
  responseLength?: string;
  language?: string;
  quantityExercises?: number;
  quantityTrueFalse?: number;
  quantityMultipleChoice?: number;
  quantityDiscursive?: number;
  instructions?: string;
  provider?: string;
  model?: string;
  baseUrl?: string;
  apiKey?: string;
  images?: Array<{ marker: string; sourceName: string; context: string }>;
};

function cleanGeneratedContent(content: string) {
  return content
    .replace(/<think>[\s\S]*?<\/think>\s*/gi, "")
    .replace(/<\/?think>/gi, "")
    .trim();
}

async function providerResponseError(response: Response, provider: string, model: string, isLocalOllama: boolean) {
  let detail = "";
  try {
    const body = await response.text();
    if (body) {
      try {
        const parsed = JSON.parse(body);
        detail = String(parsed.error?.message || parsed.error || parsed.message || "");
      } catch { detail = body.slice(0, 300); }
    }
  } catch { /* A mensagem pelo status ainda será exibida. */ }

  if (provider === "ollama") {
    if (response.status === 401 || response.status === 403 || /unauthori|login|sign.?in/i.test(detail)) {
      return "O Ollama não está autenticado. Abra o Ollama e execute “ollama login”; depois tente novamente.";
    }
    if (/model.*(?:not found|missing)|pull model|does not exist/i.test(detail)) {
      return `O modelo de IA “${model}” não está instalado ou disponível no Ollama. Execute “ollama pull ${model}” e tente novamente.`;
    }
    if (isLocalOllama && response.status === 404) {
      return `O Ollama respondeu, mas não encontrou o modelo ou a rota configurada. Confirme o modelo “${model}” e execute “ollama pull ${model}”.`;
    }
    return `O Ollama respondeu com erro ${response.status}${detail ? `: ${detail}` : "."}`;
  }
  return `O provedor de IA respondeu com erro ${response.status}${detail ? `: ${detail}` : "."}`;
}

function connectionErrorMessage(error: unknown, provider: string, model: string, isLocalOllama: boolean) {
  const message = error instanceof Error ? error.message : "";
  const cause = error instanceof Error && error.cause && typeof error.cause === "object"
    ? String((error.cause as { code?: string }).code || "")
    : "";
  if (provider === "ollama" && (isLocalOllama || /fetch failed|econnrefused|enotfound|socket|network/i.test(`${message} ${cause}`))) {
    return `O Ollama não está instalado ou não está aberto, ou o modelo de IA “${model}” não está disponível. Instale e abra o Ollama; depois execute “ollama login” e “ollama pull ${model}”.`;
  }
  return message || "Não foi possível conectar ao provedor de IA.";
}

function exercisesWereRequested(labels: string[]) {
  return labels.some((label) => /todos os materiais|exerc[ií]cios|quest[oõ]es|verdadeiro|falso|m[uú]ltipla escolha|discursiv/i.test(label));
}

function sourceBibliography(sourceText: string) {
  const lines = sourceText.split(/\r?\n/);
  const start = lines.findIndex((line) => /^(?:#{1,6}\s*)?(refer[eê]ncias(?: bibliogr[aá]ficas)?|bibliografia|fontes)\s*:?[\s*]*$/i.test(line.trim()));
  const references: string[] = [];
  if (start >= 0) {
    for (let index = start + 1; index < lines.length && references.length < 30; index += 1) {
      const line = lines[index].trim();
      if (/^#{1,3}\s+/.test(line) || /^---+$/.test(line)) break;
      if (line) references.push(line.replace(/^[-*]\s+/, ""));
    }
  }
  for (const line of lines) {
    const urls = line.match(/https?:\/\/[^\s<>"']+/gi) || [];
    for (const rawUrl of urls) {
      const url = rawUrl.replace(/[),.;:!?\]]+$/g, "");
      const cleanLine = line.trim().replace(/^[-*]\s+/, "");
      references.push(cleanLine.length <= 500 ? cleanLine : url);
    }
  }
  return references.filter((reference, index, items) => {
    const key = reference.toLocaleLowerCase("pt-BR");
    return reference && items.findIndex((item) => item.toLocaleLowerCase("pt-BR") === key) === index;
  }).slice(0, 30);
}

function ensureBibliographyBeforeAnswerKey(content: string, sourceText: string) {
  const references = sourceBibliography(sourceText);
  if (!references.length) return content;
  const existingHeading = /^##\s+refer[eê]ncias(?: bibliogr[aá]ficas)?\s*$/im.exec(content);
  if (existingHeading?.index !== undefined) {
    const sectionStart = existingHeading.index + existingHeading[0].length;
    const afterHeading = content.slice(sectionStart);
    const nextHeading = /^##\s+/m.exec(afterHeading);
    const sectionEnd = nextHeading ? sectionStart + nextHeading.index : content.length;
    const existingSection = content.slice(sectionStart, sectionEnd);
    const missing = references.filter((reference) => {
      const urls = reference.match(/https?:\/\/[^\s<>"']+/gi) || [];
      return urls.length
        ? !urls.some((url) => existingSection.includes(url.replace(/[),.;:!?\]]+$/g, "")))
        : !existingSection.toLocaleLowerCase("pt-BR").includes(reference.toLocaleLowerCase("pt-BR"));
    });
    if (!missing.length) return content;
    return `${content.slice(0, sectionEnd).trimEnd()}\n${missing.map((reference) => `- ${reference}`).join("\n")}\n\n${content.slice(sectionEnd).trimStart()}`.trim();
  }
  const section = `## Referências bibliográficas\n\n${references.map((reference) => `- ${reference}`).join("\n")}`;
  const answerIndex = content.search(/^##\s+gabarito\b/im);
  return answerIndex >= 0
    ? `${content.slice(0, answerIndex).trimEnd()}\n\n${section}\n\n${content.slice(answerIndex).trimStart()}`
    : `${content.trimEnd()}\n\n${section}`;
}

function moveAnswerKeyToEnd(content: string) {
  const match = /^##\s+gabarito\b/im.exec(content);
  if (!match?.index && match?.index !== 0) return content;
  const start = match.index;
  const remainder = content.slice(start);
  const nextSection = /^##\s+/gm;
  nextSection.lastIndex = match[0].length;
  const next = nextSection.exec(remainder);
  if (!next) return content;
  const answerKey = remainder.slice(0, next.index).trim();
  const after = remainder.slice(next.index).trim();
  return `${content.slice(0, start).trimEnd()}\n\n${after}\n\n${answerKey}`.trim();
}

function simulatedMaterial(data: GenerationRequest) {
  const source = data.sourceText.trim().slice(0, 1800) || "Conteúdo informado pelo professor.";
  const references = sourceBibliography(data.sourceText);
  const bibliography = references.length ? `\n\n## Referências bibliográficas\n\n${references.map((reference) => `- ${reference}`).join("\n")}` : "";
  const answerKey = exercisesWereRequested(data.outputLabels) ? `\n\n## Gabarito\n\n1. Resposta pessoal fundamentada no conceito central.\n2. Exemplo coerente com o cotidiano do aluno.\n3. Comparação que apresente ao menos uma semelhança e uma diferença.\n4. Síntese com as ideias principais do conteúdo.` : "";
  return `# ${data.title}\n\n**Público:** ${data.audience}\n\n**Professor(a):** ${data.teacherName || "Não informado"}\n\n## Objetivos de aprendizagem\n\n- Compreender os conceitos centrais do tema.\n- Relacionar o conteúdo com situações reais.\n- Desenvolver participação e pensamento crítico.\n\n## Plano de aula\n\n1. Acolhida e levantamento de conhecimentos prévios.\n2. Apresentação dialogada do conteúdo.\n3. Atividade prática em pequenos grupos.\n4. Socialização e síntese coletiva.\n5. Avaliação formativa e fechamento.\n\n## Conteúdo de apoio\n\n${source}\n\n## Atividades sugeridas\n\n1. Explique o conceito principal com suas palavras.\n2. Apresente um exemplo relacionado ao cotidiano.\n3. Compare duas ideias presentes no conteúdo.\n4. Produza uma síntese em cinco linhas.\n\n## Avaliação\n\nObserve a participação, a clareza das respostas e a capacidade de aplicar o conteúdo.\n\n## Materiais solicitados\n\n${data.outputLabels.map((item) => `- ${item}`).join("\n")}\n\n> Rascunho gerado no modo de demonstração. Revise antes de utilizar em aula.${bibliography}${answerKey}`;
}

export async function POST(request: Request) {
  const data = (await request.json()) as GenerationRequest;
  const provider = data.provider || process.env.AI_MODE || "simulated";
  const serverKey = provider === "minimax"
    ? process.env.MINIMAX_API_KEY || ""
    : provider === "openai"
      ? process.env.OPENAI_API_KEY || ""
      : provider === "anthropic"
        ? process.env.ANTHROPIC_API_KEY || ""
        : process.env.AI_API_KEY || "";
  const apiKey = data.apiKey?.trim() || serverKey;
  if (provider === "simulated") {
    return NextResponse.json({ content: simulatedMaterial(data), model: "simulado-professor" });
  }

  const defaultBaseUrl = provider === "minimax"
    ? process.env.MINIMAX_BASE_URL || "https://api.minimax.io/v1"
    : provider === "ollama"
      ? process.env.OLLAMA_BASE_URL || "https://ollama.com/api"
      : provider === "anthropic"
        ? process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com/v1"
        : process.env.AI_BASE_URL || "https://api.openai.com/v1";
  const defaultModel = provider === "minimax"
    ? process.env.MINIMAX_MODEL || "MiniMax-M3"
    : provider === "ollama"
      ? process.env.OLLAMA_MODEL || "gemma4:cloud"
      : provider === "anthropic"
        ? process.env.ANTHROPIC_MODEL || "claude-opus-4-8"
        : process.env.OPENAI_MODEL || "gpt-5.1";
  const requestedBaseUrl = (data.baseUrl || defaultBaseUrl).replace(/\/$/, "");
  const baseUrl = provider === "ollama"
    ? requestedBaseUrl.replace(/^http:\/\/(?:127\.0\.0\.1|localhost)(?=:\d+|\/|$)/i, "http://host.docker.internal")
    : requestedBaseUrl;
  const model = data.model || defaultModel;
  const isLocalOllama = provider === "ollama" && /(?:host\.docker\.internal|localhost|127\.0\.0\.1)(?::|\/|$)/i.test(baseUrl);
  if (!apiKey && !isLocalOllama) {
    return NextResponse.json({ error: "Informe sua chave de API em Configurações de IA antes de gerar." }, { status: 400 });
  }
  const exerciseRequested = exercisesWereRequested(data.outputLabels);
  const requestedLabels = exerciseRequested && !data.outputLabels.some((label) => /gabarito/i.test(label)) ? [...data.outputLabels, "Gabarito"] : data.outputLabels;
  const allMaterialsRequested = Boolean(data.outputTypes?.includes("all") || data.outputLabels.some((label) => /todos os materiais/i.test(label)));
  const presentationInstruction = allMaterialsRequested || data.outputLabels.some((label) => /powerpoint|apresenta/i.test(label))
    ? `\n\nInclua uma seção exclusiva chamada exatamente \"## Apresentação para os alunos\". Ela deve ser diferente do plano do professor e pronta para projeção em sala. Use este formato para cada tela:\n### Slide 1 — Título curto\n- ideia visível para o aluno\n- no máximo 5 tópicos curtos\nCrie uma sequência didática clara, sem plano de aula, duração, orientações ao professor, checklist, respostas ou gabarito. Não use tabelas para descrever os slides e não escreva instruções como \"inserir imagem\".`
    : "";
  const teacherExpositoryInstruction = allMaterialsRequested || data.outputLabels.some((label) => /roteiro expositivo|expositiv.*professor/i.test(label))
    ? `\n\nInclua uma seção exclusiva chamada exatamente \"## Roteiro expositivo para o professor\". Escreva como apoio prático ao docente durante a explicação, sem transformar o texto em slides. Organize em: abertura e conexão com conhecimentos prévios; sequência dos conceitos em ordem didática; exemplos que o professor pode explicar; perguntas para envolver a turma; alertas sobre dúvidas ou confusões comuns; síntese e fechamento. Use subtítulos de nível 3 e ofereça falas sugeridas naturais, não um discurso rígido para leitura.`
    : "";
  const imageInventory = (data.images || []).slice(0, 30);
  const imageInstruction = imageInventory.length ? `\n\nHá imagens reais extraídas dos arquivos do professor. Use somente quando forem relacionadas ao assunto do trecho. Para posicionar uma imagem no Word, escreva o marcador sozinho em uma linha na seção apropriada. Na seção "Apresentação para os alunos", também pode usar o marcador sozinho dentro do slide adequado. Não descreva nem invente imagens e não altere os marcadores. Cada imagem pode aparecer no máximo uma vez no corpo do Word e uma vez na apresentação. Imagens disponíveis:\n${imageInventory.map((image) => `- [${image.marker}] — fonte: ${image.sourceName}; contexto próximo: ${image.context || "não identificado"}`).join("\n")}` : "";
  const answerAndReferenceInstruction = `${exerciseRequested ? `\n\nComo há exercícios solicitados, inclua obrigatoriamente \"## Gabarito\" com respostas para todos os exercícios. O Gabarito deve ser a última seção de todo o material.` : ""}\n\nSe a fonte fornecida contiver referências, bibliografia ou endereços web, inclua \"## Referências bibliográficas\" reproduzindo somente as fontes realmente presentes no documento, sem inventar autores, títulos, datas ou links. Todo endereço web informado pelo professor deve aparecer literalmente nessa seção. Ela deve ficar imediatamente antes do Gabarito; se não houver referências nem links na fonte, não crie essa seção.`;
  const exerciseInstruction = exercisePromptInstruction(data);
  const prompt = `Crie material didático completo em Markdown e escreva exclusivamente em Português do Brasil.\nTítulo: ${data.title}\nProfessor(a): ${data.teacherName || "não informado"}\nPúblico: ${data.audience}\nNível: ${data.educationLevel}\nModelo pedagógico: ${data.pedagogicalModel}\nEstilo de explicação: ${data.explanationStyle || "claro"}\nExtensão desejada: ${data.responseLength || "média"}\nIdioma obrigatório: ${data.language || "pt-BR"}\nEntregas: ${requestedLabels.join(", ")}${exerciseInstruction}\nInstruções adicionais: ${data.instructions || "nenhuma"}${teacherExpositoryInstruction}${presentationInstruction}${answerAndReferenceInstruction}${imageInstruction}\n\nOrganize cada parte principal com título de nível 2 (##). Dentro dos exercícios, dê um título de nível 3 (###) somente para cada tipo de atividade solicitado. Não mostre raciocínio interno, análise, planejamento oculto ou tags <think>. Entregue somente o material final pronto para revisão.\n\nFonte fornecida pelo professor:\n${data.sourceText}`;
  try {
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    const anthropicApi = provider === "anthropic";
    if (anthropicApi) {
      headers["x-api-key"] = apiKey;
      headers["anthropic-version"] = "2023-06-01";
    } else if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
    const nativeOllamaApi = provider === "ollama" && /\/api$/i.test(baseUrl);
    const systemPrompt = "Você é um especialista em educação brasileira. Responda exclusivamente em Português do Brasil, em Markdown, apresentando apenas o material final. Nunca exponha raciocínio interno, análise ou tags <think>.";
    const endpoint = anthropicApi ? `${baseUrl}/messages` : nativeOllamaApi ? `${baseUrl}/chat` : `${baseUrl}/chat/completions`;
    const body = anthropicApi
      ? { model, max_tokens: 16000, system: systemPrompt, messages: [{ role: "user", content: prompt }] }
      : { model, ...(nativeOllamaApi ? { stream: false } : {}), ...(provider === "minimax" ? { reasoning_split: true } : {}), messages: [{ role: "system", content: systemPrompt }, { role: "user", content: prompt }] };
    const response = await fetch(endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
    });
    if (!response.ok) throw new Error(await providerResponseError(response, provider, model, isLocalOllama));
    const result = await response.json();
    const rawContent = anthropicApi
      ? (result.content || []).filter((block: { type?: string; text?: string }) => block.type === "text").map((block: { text?: string }) => block.text || "").join("\n")
      : nativeOllamaApi ? result.message?.content || "" : result.choices?.[0]?.message?.content || "";
    const selectedOnly = filterUnrequestedExerciseSections(cleanGeneratedContent(rawContent), data.outputTypes);
    const generated = moveAnswerKeyToEnd(ensureBibliographyBeforeAnswerKey(selectedOnly, data.sourceText));
    return NextResponse.json({ content: generated || simulatedMaterial(data), model });
  } catch (error) {
    return NextResponse.json({ error: connectionErrorMessage(error, provider, model, isLocalOllama) }, { status: 502 });
  }
}
