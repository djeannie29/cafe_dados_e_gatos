import path from "node:path";

export const STORAGE_ROOT = path.resolve(/* turbopackIgnore: true */ process.env.STORAGE_ROOT || "storage");

export function materialStoragePath(materialId: string) {
  if (!/^[a-zA-Z0-9-]{8,80}$/.test(materialId)) throw new Error("Identificador de material inválido.");
  const target = path.resolve(STORAGE_ROOT, "materials", materialId);
  if (!target.startsWith(`${STORAGE_ROOT}${path.sep}`)) throw new Error("Caminho de armazenamento inválido.");
  return target;
}

export function imageExtension(mimeType: string) {
  return ({
    "image/png": "png",
    "image/jpeg": "jpg",
    "image/gif": "gif",
    "image/bmp": "bmp",
  } as Record<string, string>)[mimeType];
}
