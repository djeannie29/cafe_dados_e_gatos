import { readFile } from "node:fs/promises";
import path from "node:path";
import JSZip from "jszip";
import { NextResponse } from "next/server";
import { db, ensureSchema, hasDatabase } from "@/lib/db";
import { materialStoragePath } from "@/lib/storage";

const LOCAL_USER = "local-professor";

function safeName(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^-|-$/g, "") || "imagem";
}

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  if (!hasDatabase()) return new NextResponse(null, { status: 404 });
  const { id } = await context.params;
  await ensureSchema();
  const rows = await db()<Array<{ title: string; storedName: string; originalName: string }>>`SELECT m.title, i.stored_name AS "storedName", i.original_name AS "originalName" FROM material_images i JOIN materials m ON m.id = i.material_id WHERE i.material_id = ${id} AND m.user_id = ${LOCAL_USER} ORDER BY i.sort_order`;
  if (!rows.length) return NextResponse.json({ error: "Este material não possui imagens salvas." }, { status: 404 });

  const zip = new JSZip();
  const names = new Map<string, number>();
  for (const image of rows) {
    if (path.basename(image.storedName) !== image.storedName) continue;
    try {
      const data = await readFile(path.join(/* turbopackIgnore: true */ materialStoragePath(id), image.storedName));
      const base = safeName(image.originalName);
      const count = names.get(base) || 0;
      names.set(base, count + 1);
      const extension = path.extname(base);
      const stem = extension ? base.slice(0, -extension.length) : base;
      zip.file(count ? `${stem}-${count + 1}${extension}` : base, data);
    } catch { /* Mantém no ZIP as demais imagens que continuam disponíveis. */ }
  }
  const archive = await zip.generateAsync({ type: "arraybuffer", compression: "DEFLATE", compressionOptions: { level: 6 } });
  const filename = `${safeName(rows[0].title)}-imagens.zip`;
  return new NextResponse(archive, { headers: { "Content-Type": "application/zip", "Content-Disposition": `attachment; filename="${filename}"`, "Cache-Control": "no-store" } });
}
