@echo off
cd /d "%~dp0"
title Central de Conteudo com IA - Iniciar

echo.
echo ==============================================
echo   Central de Conteudo com IA - Professor
echo ==============================================
echo.

where docker >nul 2>&1
if errorlevel 1 (
  echo Docker nao foi encontrado.
  echo Instale e abra o Docker Desktop antes de continuar.
  echo https://www.docker.com/products/docker-desktop/
  pause
  exit /b 1
)

docker info >nul 2>&1
if errorlevel 1 (
  echo O Docker Desktop esta instalado, mas ainda nao esta pronto.
  echo Abra o Docker Desktop, aguarde aparecer "Engine running" e tente novamente.
  pause
  exit /b 1
)

if not exist ".env" (
  echo Criando a configuracao protegida desta instalacao...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\initialize-env.ps1"
  if errorlevel 1 (
    echo Nao foi possivel criar a configuracao local.
    pause
    exit /b 1
  )
)

echo Preparando a aplicacao. Na primeira execucao isso pode levar alguns minutos...
docker compose up -d --build
if errorlevel 1 (
  echo.
  echo Nao foi possivel iniciar. Execute DIAGNOSTICO.cmd e envie o arquivo gerado.
  pause
  exit /b 1
)

echo Aguardando a aplicacao ficar pronta...
for /l %%I in (1,1,60) do (
  powershell -NoProfile -Command "try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:5000/api/health' -TimeoutSec 2; if($r.status -eq 'ok'){exit 0}; exit 1 } catch { exit 1 }" >nul 2>&1
  if not errorlevel 1 goto :ready
  timeout /t 2 /nobreak >nul
)

echo A aplicacao demorou mais que o esperado para responder.
echo Execute DIAGNOSTICO.cmd para obter mais informacoes.
pause
exit /b 1

:ready
echo.
echo Aplicacao pronta. Abrindo no navegador...
start "" "http://127.0.0.1:5000"
echo.
echo Seus materiais ficam salvos nesta instalacao.
pause
