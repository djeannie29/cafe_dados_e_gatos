[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$envPath = Join-Path $projectRoot ".env"

if (Test-Path -LiteralPath $envPath) {
  Write-Host "Configuração local existente preservada."
  exit 0
}

function New-HexToken([int]$ByteCount) {
  $bytes = New-Object byte[] $ByteCount
  $generator = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  try { $generator.GetBytes($bytes) } finally { $generator.Dispose() }
  return ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
}

$postgresPassword = New-HexToken 24
$projectSuffix = New-HexToken 4
$envContent = @"
COMPOSE_PROJECT_NAME=central-conteudo-professor-$projectSuffix
POSTGRES_PASSWORD=$postgresPassword
COOKIE_SECURE=false
AI_MODE=ollama
OLLAMA_MODEL=gemma4:cloud
OLLAMA_BASE_URL=http://host.docker.internal:11434/v1
"@

[IO.File]::WriteAllText($envPath, $envContent, [Text.UTF8Encoding]::new($false))
Write-Host "Configuração local protegida criada."
