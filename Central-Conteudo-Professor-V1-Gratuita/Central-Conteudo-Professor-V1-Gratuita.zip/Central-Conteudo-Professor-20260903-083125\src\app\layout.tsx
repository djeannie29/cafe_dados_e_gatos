import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Central de Conteúdo com IA — Professor",
  description: "Crie materiais didáticos com inteligência artificial.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR" data-theme="dark" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: `try{const theme=localStorage.getItem("professor-theme");document.documentElement.dataset.theme=theme==="light"?"light":"dark"}catch{document.documentElement.dataset.theme="dark"}` }} /></head>
      <body>{children}</body>
    </html>
  );
}
