import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { db, ensureSchema, hasDatabase } from "@/lib/db";
import { materialStoragePath } from "@/lib/storage";

const LOCAL_USER = "local-professor";

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  if (!hasDatabase()) return new NextResponse(null, { status: 404 });
  const { id } = await context.params;
  await ensureSchema();
  const rows = await db()<Array<{ materialId: string; storedName: string; mimeType: string }>>`SELECT i.material_id AS "materialId", i.stored_name AS "storedName", i.mime_type AS "mimeType" FROM material_images i JOIN materials m ON m.id = i.material_id WHERE i.id = ${id} AND m.user_id = ${LOCAL_USER}`;
  const image = rows[0];
  if (!image || path.basename(image.storedName) !== image.storedName) return new NextResponse(null, { status: 404 });
  try {
    const data = await readFile(path.join(/* turbopackIgnore: true */ materialStoragePath(image.materialId), image.storedName));
    return new NextResponse(data, { headers: { "Content-Type": image.mimeType, "Cache-Control": "private, max-age=3600", "X-Content-Type-Options": "nosniff" } });
  } catch { return new NextResponse(null, { status: 404 }); }
}
