"use client";

import Image from "next/image";
import { useEffect, useMemo, useState } from "react";
import { BookOpen, CheckCircle2, Clock3, Download, FilePlus2, FolderArchive, History, Home, Menu, Moon, Search, Settings, Sparkles, Sun, Trash2, Upload, X } from "lucide-react";
import { aiProviders, educationLevels, explanationStyles, languages, outputTypes, pedagogicalModels, responseLengths, sourceTypes } from "@/lib/options";
import { exportMaterial, extractFiles, type MaterialImage } from "@/lib/files";

type View = "home" | "new" | "history" | "ready" | "settings" | "detail";
type Material = { id: string; title: string; audience: string; teacherName: string; sourceType: string; outputTypes: string[]; educationLevel: string; pedagogicalModel: string; content: string; model: string; createdAt: string; status: "generated" | "draft"; images: MaterialImage[] };
type FormState = { title: string; teacherName: string; audience: string; sourceType: string; sourceText: string; outputTypes: string[]; educationLevel: string; pedagogicalModel: string; explanationStyle: string; responseLength: string; language: string; instructions: string; quantityExercises: number; quantityTrueFalse: number; quantityMultipleChoice: number; quantityDiscursive: number };
type AISettings = { provider: string; model: string; baseUrl: string; apiKey: string };
type Theme = "light" | "dark";

const initialForm: FormState = { title: "", teacherName: "", audience: "", sourceType: "text", sourceText: "", outputTypes: ["all"], educationLevel: "fundamental_2", pedagogicalModel: "active_learning", explanationStyle: "clear", responseLength: "medium", language: "pt-BR", instructions: "", quantityExercises: 8, quantityTrueFalse: 5, quantityMultipleChoice: 5, quantityDiscursive: 3 };
const exerciseOutputTypes = new Set(["exercises", "assessment", "true_false", "multiple_choice", "discursive"]);
const initialAI: AISettings = { provider: "ollama", model: "gemma4:cloud", baseUrl: "http://host.docker.internal:11434/v1", apiKey: "" };
const labelOf = (items: readonly (readonly string[])[], value: string) => items.find((item) => item[0] === value)?.[1] || value;

function detectedFileSourceType(files: File[]) {
  if (!files.length) return "text";
  if (files.length > 1) return "multiple";
  const name = files[0].name.toLowerCase();
  if (name.endsWith(".pdf")) return "pdf";
  if (name.endsWith(".docx")) return "docx";
  if (/\.(png|jpe?g|webp|tiff?)$/.test(name)) return "image";
  if (/\.(md|markdown)$/.test(name)) return "markdown";
  if (/\.(txt|srt|vtt)$/.test(name)) return "transcription";
  return "multiple";
}

export function ProfessorApp() {
  const [view, setView] = useState<View>("home");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [storageMode, setStorageMode] = useState<"database" | "browser">("browser");
  const [selectedId, setSelectedId] = useState("");
  const [hydrated, setHydrated] = useState(false);
  const [form, setForm] = useState<FormState>(initialForm);
  const [ai, setAI] = useState<AISettings>(initialAI);
  const [step, setStep] = useState(1);
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [theme, setTheme] = useState<Theme>("dark");

  useEffect(() => {
    const saved = localStorage.getItem("professor-theme");
    const next: Theme = saved === "light" ? "light" : "dark";
    setTheme(next);
    document.documentElement.dataset.theme = next;
  }, []);

  useEffect(() => { (async () => {
    try {
      const response = await fetch("/api/materials");
      if (response.ok) {
        const result = await response.json();
        setMaterials(result.materials || []);
        setStorageMode("database");
      } else {
        setMaterials(JSON.parse(localStorage.getItem("professor-materials") || "[]"));
        setStorageMode("browser");
      }
      const savedAI = JSON.parse(localStorage.getItem("professor-ai") || "{}");
      const migrateToGemma = !savedAI.provider || savedAI.provider === "minimax" || savedAI.provider === "anthropic";
      setAI(migrateToGemma ? initialAI : { ...initialAI, provider: savedAI.provider, model: savedAI.model || initialAI.model, baseUrl: savedAI.baseUrl || initialAI.baseUrl, apiKey: "" });
    } finally { setHydrated(true); }
  })(); }, []);
  useEffect(() => { if (hydrated && storageMode === "browser") localStorage.setItem("professor-materials", JSON.stringify(materials)); }, [materials, hydrated, storageMode]);
  useEffect(() => { if (hydrated) localStorage.setItem("professor-ai", JSON.stringify({ provider: ai.provider, model: ai.model, baseUrl: ai.baseUrl })); }, [ai.provider, ai.model, ai.baseUrl, hydrated]);

  const selected = materials.find((item) => item.id === selectedId);
  const filtered = useMemo(() => materials.filter((item) => `${item.title} ${item.audience} ${item.teacherName}`.toLowerCase().includes(search.toLowerCase())), [materials, search]);
  const navigate = (next: View) => { setView(next); setMobileOpen(false); setError(""); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const toggleTheme = () => setTheme((current) => { const next = current === "dark" ? "light" : "dark"; document.documentElement.dataset.theme = next; localStorage.setItem("professor-theme", next); return next; });
  const openMaterial = (id: string) => { setSelectedId(id); navigate("detail"); };
  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((current) => ({ ...current, [key]: value }));
  const toggleOutput = (value: string) => {
    if (value === "all") { update("outputTypes", ["all"]); return; }
    const current = form.outputTypes.filter((item) => item !== "all");
    const hasExercises = current.some((item) => exerciseOutputTypes.has(item));
    if (value === "answer_key" && hasExercises) return;
    let next = current.includes(value) ? current.filter((item) => item !== value) : [...current, value];
    if (exerciseOutputTypes.has(value) && !current.includes(value) && !next.includes("answer_key")) next.push("answer_key");
    if (exerciseOutputTypes.has(value) && current.includes(value) && !next.some((item) => exerciseOutputTypes.has(item))) next = next.filter((item) => item !== "answer_key");
    update("outputTypes", next);
  };

  async function generate() {
    setError("");
    if (!form.title.trim() || !form.audience.trim() || !form.outputTypes.length) { setError("Preencha o título, a turma e selecione ao menos um material."); return; }
    try {
      setBusy(files.length ? "Lendo os arquivos enviados..." : "Preparando a solicitação...");
      const extracted = files.length ? await extractFiles(files, setBusy) : { text: "", images: [] };
      const sourceText = [form.sourceText, extracted.text].filter(Boolean).join("\n\n");
      if (!sourceText.trim()) throw new Error("Cole um texto ou envie pelo menos um arquivo.");
      setBusy("Gerando o material didático...");
      const response = await fetch("/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...form, sourceText, images: extracted.images.map(({ marker, sourceName, context }) => ({ marker, sourceName, context })), outputLabels: form.outputTypes.map((item) => labelOf(outputTypes, item)), provider: ai.provider, model: ai.model, baseUrl: ai.baseUrl, apiKey: ai.apiKey }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Não foi possível gerar o material.");
      const material: Material = { id: crypto.randomUUID(), title: form.title, audience: form.audience, teacherName: form.teacherName, sourceType: form.sourceType, outputTypes: form.outputTypes, educationLevel: form.educationLevel, pedagogicalModel: form.pedagogicalModel, content: result.content, model: result.model, createdAt: new Date().toISOString(), status: "generated", images: [] };
      if (storageMode === "database") {
        const saved = await fetch("/api/materials", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(material) });
        if (!saved.ok) throw new Error("O material foi gerado, mas não pôde ser salvo no banco local.");
        if (extracted.images.length) {
          setBusy("Salvando as imagens do material...");
          const upload = new FormData();
          upload.set("metadata", JSON.stringify(extracted.images.map(({ marker, sourceName, context, width, height }) => ({ marker, sourceName, context, width, height }))));
          for (const image of extracted.images) upload.append("images", image.file, image.file.name);
          const uploaded = await fetch(`/api/materials/${material.id}/images`, { method: "POST", body: upload });
          if (!uploaded.ok) {
            await fetch(`/api/materials/${material.id}`, { method: "DELETE" });
            throw new Error("O material foi gerado, mas as imagens não puderam ser salvas. Nada foi perdido dos materiais anteriores; tente novamente.");
          }
          material.images = (await uploaded.json()).images || [];
        }
      }
      setMaterials((current) => [material, ...current]); setSelectedId(material.id); setForm(initialForm); setFiles([]); setStep(1); navigate("detail");
    } catch (exception) {
      const message = exception instanceof Error ? exception.message : "Falha inesperada.";
      setError(ai.provider === "ollama" && /failed to fetch|fetch failed|networkerror|load failed/i.test(message)
        ? `O Ollama não está instalado ou não está aberto, ou o modelo de IA “${ai.model}” não está disponível. Instale e abra o Ollama; depois execute “ollama login” e “ollama pull ${ai.model}”.`
        : message);
    }
    finally { setBusy(""); }
  }

  async function remove(id: string) { if (confirm("Excluir este material?")) { if (storageMode === "database") { const response = await fetch(`/api/materials/${id}`, { method: "DELETE" }); if (!response.ok) return; } setMaterials((current) => current.filter((item) => item.id !== id)); if (selectedId === id) navigate("history"); } }

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
      <button className="mobile-close" onClick={() => setMobileOpen(false)} aria-label="Fechar menu"><X /></button>
      <button className="brand" onClick={() => navigate("home")}><Image src="/brand-logo.png" alt="" width={52} height={52} priority /><span><strong>Central de Conteúdo</strong><small>Professor</small></span></button>
      <nav>
        <Nav active={view === "home"} icon={<Home />} label="Início" onClick={() => navigate("home")} />
        <Nav active={view === "new"} icon={<FilePlus2 />} label="Novo material" onClick={() => navigate("new")} />
        <Nav active={view === "history" || view === "detail"} icon={<History />} label="Histórico" onClick={() => navigate("history")} />
        <Nav active={view === "ready"} icon={<Download />} label="Materiais prontos" onClick={() => navigate("ready")} />
        <Nav active={view === "settings"} icon={<Settings />} label="Configurações" onClick={() => navigate("settings")} />
      </nav>
      <div className="sidebar-bottom"><ThemeButton theme={theme} onClick={toggleTheme} /><div className="access-chip"><span></span>Uso gratuito</div><small>{storageMode === "database" ? "Materiais salvos nesta máquina" : "Demonstração no navegador"}</small></div>
    </aside>
    {mobileOpen && <button className="backdrop" onClick={() => setMobileOpen(false)} aria-label="Fechar menu" />}
    <main><header className="mobile-header"><button onClick={() => setMobileOpen(true)} aria-label="Abrir menu"><Menu /></button><span>Central de Conteúdo</span><ThemeButton theme={theme} onClick={toggleTheme} compact /></header>
      {!hydrated ? <div className="loading-page"><Sparkles /> Preparando seu espaço...</div> : <>
        {view === "home" && <Dashboard materials={materials} ai={ai} navigate={navigate} openMaterial={openMaterial} />}
        {view === "new" && <NewMaterial form={form} update={update} step={step} setStep={setStep} files={files} setFiles={setFiles} toggleOutput={toggleOutput} generate={generate} error={error} />}
        {view === "history" && <HistoryView title="Histórico" subtitle="Materiais criados e suas versões." materials={filtered} search={search} setSearch={setSearch} openMaterial={openMaterial} remove={remove} />}
        {view === "ready" && <HistoryView title="Materiais prontos" subtitle="Baixe seus conteúdos nos formatos desejados." materials={filtered.filter((item) => item.status === "generated")} search={search} setSearch={setSearch} openMaterial={openMaterial} remove={remove} ready />}
        {view === "settings" && <SettingsView ai={ai} setAI={setAI} />}
        {view === "detail" && selected && <Detail material={selected} setMaterials={setMaterials} remove={remove} storageMode={storageMode} />}
      </>}
    </main>
    {busy && <div className="processing"><div><Image src="/brand-logo.png" alt="" width={74} height={74} /><Sparkles /><h2>Preparando sua aula</h2><p>{busy}</p><span className="progress"><i /></span></div></div>}
  </div>;
}

function Nav({ active, icon, label, onClick }: { active: boolean; icon: React.ReactNode; label: string; onClick: () => void }) { return <button className={active ? "active" : ""} onClick={onClick}>{icon}<span>{label}</span></button>; }

function ThemeButton({ theme, onClick, compact, floating }: { theme: Theme; onClick: () => void; compact?: boolean; floating?: boolean }) {
  const dark = theme === "dark";
  return <button type="button" className={`theme-toggle${compact ? " compact" : ""}${floating ? " floating" : ""}`} onClick={onClick} aria-label={dark ? "Ativar modo claro" : "Ativar modo escuro"}>{dark ? <Sun /> : <Moon />}{!compact && <span>{dark ? "Modo claro" : "Modo escuro"}</span>}</button>;
}

function Dashboard({ materials, ai, navigate, openMaterial }: { materials: Material[]; ai: AISettings; navigate: (view: View) => void; openMaterial: (id: string) => void }) {
  return <section className="workspace dashboard"><div className="hero"><div><p className="eyebrow">Visão geral</p><h1>Olá, Professor(a)</h1><p>O que vamos preparar para a aula de hoje?</p><div className="ai-chip"><span></span><small>IA ativa</small><strong>{labelOf(aiProviders, ai.provider)} · {ai.model}</strong></div></div><Image src="/dashboard-educator.png" alt="Professora organizando materiais de aula" width={330} height={270} priority /></div>
    <div className="quick-grid"><Quick icon={<FilePlus2 />} title="Novo material" text="Criar conteúdo para aula" color="teal" onClick={() => navigate("new")} /><Quick icon={<History />} title="Histórico" text={`${materials.length} materiais salvos`} color="blue" onClick={() => navigate("history")} /><Quick icon={<Download />} title="Materiais prontos" text="Word, PowerPoint, Markdown ou texto" color="amber" onClick={() => navigate("ready")} /><Quick icon={<Settings />} title="Configurações" text="Provedor e modelo de IA" color="coral" onClick={() => navigate("settings")} /></div>
    <div className="dashboard-grid"><section className="panel"><PanelTitle eyebrow="Atividade" title="Materiais recentes" action="Ver histórico" onAction={() => navigate("history")} />{materials.length ? <div className="recent-list">{materials.slice(0, 5).map((item) => <button key={item.id} onClick={() => openMaterial(item.id)}><i></i><span><strong>{item.title}</strong><small>{item.audience}{item.teacherName ? ` · ${item.teacherName}` : ""}</small></span><em>Gerado</em></button>)}</div> : <Empty text="Seu primeiro material aparecerá aqui." action="Criar agora" onAction={() => navigate("new")} />}</section>
      <aside className="panel summary"><PanelTitle eyebrow="Biblioteca" title="Resumo" /><div className="metrics"><div><strong>{materials.length}</strong><span>Total</span></div><div><strong>{materials.filter((item) => item.status === "generated").length}</strong><span>Gerados</span></div><div><strong>0</strong><span>Rascunhos</span></div></div><div className="active-line"><CheckCircle2 /><span><strong>Aplicação ativa</strong><small>Pronta para criar materiais</small></span></div></aside></div></section>;
}

function Quick({ icon, title, text, color, onClick }: { icon: React.ReactNode; title: string; text: string; color: string; onClick: () => void }) { return <button className={`quick ${color}`} onClick={onClick}><span>{icon}</span><div><strong>{title}</strong><small>{text}</small></div></button>; }
function PanelTitle({ eyebrow, title, action, onAction }: { eyebrow: string; title: string; action?: string; onAction?: () => void }) { return <div className="panel-title"><div><p className="eyebrow">{eyebrow}</p><h2>{title}</h2></div>{action && <button onClick={onAction}>{action}</button>}</div>; }
function Empty({ text, action, onAction }: { text: string; action: string; onAction: () => void }) { return <div className="empty"><BookOpen /><p>{text}</p><button onClick={onAction}>{action}</button></div>; }

function NewMaterial({ form, update, step, setStep, files, setFiles, toggleOutput, generate, error }: { form: FormState; update: <K extends keyof FormState>(key: K, value: FormState[K]) => void; step: number; setStep: (step: number) => void; files: File[]; setFiles: React.Dispatch<React.SetStateAction<File[]>>; toggleOutput: (value: string) => void; generate: () => void; error: string }) {
  const documentFiles = files.filter((file) => !file.name.toLowerCase().endsWith(".pptx"));
  const presentationFiles = files.filter((file) => file.name.toLowerCase().endsWith(".pptx"));
  const contentSourceTypes: readonly (readonly string[])[] = [["", "Nenhum arquivo selecionado"], ...sourceTypes.filter(([value]) => value !== "pptx" && value !== "text")];
  const canContinue = form.title.trim() && form.audience.trim() && (form.sourceText.trim() || documentFiles.length);
  const mixedQuestions = form.outputTypes.some((value) => value === "all" || value === "assessment");
  const showGeneral = mixedQuestions || form.outputTypes.includes("exercises");
  const showTrueFalse = mixedQuestions || form.outputTypes.includes("true_false");
  const showMultipleChoice = mixedQuestions || form.outputTypes.includes("multiple_choice");
  const showDiscursive = mixedQuestions || form.outputTypes.includes("discursive");
  const hasQuestionQuantity = showGeneral || showTrueFalse || showMultipleChoice || showDiscursive;
  return <section className="workspace creation"><div className="creation-hero"><div><p className="eyebrow">Novo material</p><h1>Criar conteúdo para aula</h1><p>Transforme uma fonte em material didático pronto para revisar e exportar.</p></div><Image src="/creation-materials.png" alt="Materiais educacionais organizados com IA" width={270} height={220} priority /></div>
    {error && <div className="alert">{error}</div>}<div className="wizard"><ol className="steps">{[[1,"Conteúdo","Fonte e identificação"],[2,"Configuração","Objetivo pedagógico"],[3,"Gerar","Revisão e produção"]].map(([number,title,subtitle]) => <li key={number} className={step === number ? "active" : step > Number(number) ? "done" : ""}><span>{number}</span><div><strong>{title}</strong><small>{subtitle}</small></div></li>)}</ol>
      {step === 1 && <div className="wizard-body"><SectionTitle step="Etapa 1" title="Conteúdo de origem" /><div className="fields two"><Field label="Título do material"><input value={form.title} onChange={(event) => update("title", event.target.value)} placeholder="Revolução Industrial" /></Field><Field label="Professor(a)"><input value={form.teacherName} onChange={(event) => update("teacherName", event.target.value)} placeholder="Nome do(a) professor(a)" /></Field><Field label="Turma ou público"><input value={form.audience} onChange={(event) => update("audience", event.target.value)} placeholder="8º ano do Ensino Fundamental" /></Field><Field label="Tipo do arquivo principal (detectado automaticamente)"><Select value={documentFiles.length ? form.sourceType : ""} options={contentSourceTypes} onChange={() => {}} disabled /></Field></div>
        <div className="upload-source-grid">
          <label className={`dropzone ${documentFiles.length ? "has-files" : ""}`}><input type="file" multiple accept=".pdf,.docx,.md,.markdown,.txt,.srt,.vtt,.png,.jpg,.jpeg,.webp,.tif,.tiff,text/plain,text/markdown,image/*,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document" onChange={(event) => { const selected = [...event.target.files || []]; if (!selected.length) return; setFiles((current) => [...current.filter((file) => file.name.toLowerCase().endsWith(".pptx")), ...selected]); update("sourceType", detectedFileSourceType(selected)); }} /><Upload /><strong>{documentFiles.length ? documentFiles.length === 1 ? documentFiles[0].name : `${documentFiles.length} documentos selecionados` : "Documentos e conteúdo"}</strong><span>{documentFiles.length ? documentFiles.map((file) => file.name).join(" · ") : "PDF, Word (.docx), imagem, Markdown ou transcrição"}</span></label>
          <label className={`dropzone presentation ${presentationFiles.length ? "has-files" : ""}`}><input type="file" multiple accept=".pptx,application/vnd.openxmlformats-officedocument.presentationml.presentation" onChange={(event) => { const selected = [...event.target.files || []]; setFiles((current) => [...current.filter((file) => !file.name.toLowerCase().endsWith(".pptx")), ...selected]); }} /><Upload /><strong>{presentationFiles.length ? presentationFiles.length === 1 ? presentationFiles[0].name : `${presentationFiles.length} apresentações selecionadas` : "PowerPoint de apoio (opcional)"}</strong><span>{presentationFiles.length ? presentationFiles.map((file) => file.name).join(" · ") : "Apresentação complementar do professor em formato PPTX"}</span></label>
        </div>
        <Field label="Texto, complemento ou fontes web de origem (opcional)"><textarea rows={9} value={form.sourceText} onChange={(event) => update("sourceText", event.target.value)} placeholder="Cole um conteúdo, acrescente observações ou informe os links das fontes web usadas como origem do material." /></Field><Actions next="Continuar" onNext={() => canContinue ? setStep(2) : alert("Preencha título, turma e envie o conteúdo principal ou cole um texto. O PowerPoint de apoio é opcional.")} /></div>}
      {step === 2 && <div className="wizard-body"><SectionTitle step="Etapa 2" title="Configuração pedagógica" /><fieldset><legend>Materiais desejados</legend><div className="choice-grid">{outputTypes.map(([value,label]) => <label key={value} className={value === "all" ? "choice all" : "choice"}><input type="checkbox" checked={form.outputTypes.includes(value)} onChange={() => toggleOutput(value)} disabled={value === "answer_key" && form.outputTypes.some((item) => exerciseOutputTypes.has(item))} /><span>{label}</span></label>)}</div></fieldset>
        {hasQuestionQuantity && <div className="question-quantities"><p>Quantidade somente para os tipos selecionados</p><div className="fields four">{showGeneral && <Field label="Exercícios gerais"><input type="number" min="1" max="50" value={form.quantityExercises} onChange={(event) => update("quantityExercises", Number(event.target.value))} /></Field>}{showTrueFalse && <Field label="Verdadeiro ou falso"><input type="number" min="1" max="50" value={form.quantityTrueFalse} onChange={(event) => update("quantityTrueFalse", Number(event.target.value))} /></Field>}{showMultipleChoice && <Field label="Múltipla escolha"><input type="number" min="1" max="50" value={form.quantityMultipleChoice} onChange={(event) => update("quantityMultipleChoice", Number(event.target.value))} /></Field>}{showDiscursive && <Field label="Discursivas"><input type="number" min="1" max="50" value={form.quantityDiscursive} onChange={(event) => update("quantityDiscursive", Number(event.target.value))} /></Field>}</div></div>}
        <div className="fields two"><Field label="Nível de ensino"><Select value={form.educationLevel} options={educationLevels} onChange={(value) => update("educationLevel", value)} /></Field><Field label="Modelo pedagógico"><Select value={form.pedagogicalModel} options={pedagogicalModels} onChange={(value) => update("pedagogicalModel", value)} /></Field></div><details><summary>Configurações avançadas</summary><div className="fields three"><Field label="Estilo"><Select value={form.explanationStyle} options={explanationStyles} onChange={(value) => update("explanationStyle", value)} /></Field><Field label="Tamanho"><Select value={form.responseLength} options={responseLengths} onChange={(value) => update("responseLength", value)} /></Field><Field label="Idioma"><Select value={form.language} options={languages} onChange={(value) => update("language", value)} /></Field></div><Field label="Instruções adicionais"><textarea rows={4} value={form.instructions} onChange={(event) => update("instructions", event.target.value)} /></Field></details><Actions back onBack={() => setStep(1)} next="Revisar" onNext={() => form.outputTypes.length ? setStep(3) : alert("Selecione ao menos um material.")} /></div>}
      {step === 3 && <div className="wizard-body"><SectionTitle step="Etapa 3" title="Revisar e gerar" /><div className="review">{[["Título",form.title],["Turma",form.audience],["Entrada",labelOf(sourceTypes,form.sourceType)],["Materiais",form.outputTypes.map((item)=>labelOf(outputTypes,item)).join(", ")],["Nível",labelOf(educationLevels,form.educationLevel)],["Modelo",labelOf(pedagogicalModels,form.pedagogicalModel)]].map(([key,value]) => <div key={key}><span>{key}</span><strong>{value}</strong></div>)}</div><div className="ready-callout"><CheckCircle2 /><div><strong>Pronto para gerar</strong><p>O material será salvo automaticamente na biblioteca desta instalação.</p></div></div><Actions back onBack={() => setStep(2)} next="Gerar material" onNext={generate} /></div>}
    </div></section>;
}

function SectionTitle({ step, title }: { step: string; title: string }) { return <div className="section-title"><p className="eyebrow">{step}</p><h2>{title}</h2></div>; }
function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="field"><span>{label}</span>{children}</label>; }
function Select({ value, options, onChange, disabled }: { value: string; options: readonly (readonly string[])[]; onChange: (value: string) => void; disabled?: boolean }) { return <select value={value} onChange={(event) => onChange(event.target.value)} disabled={disabled}>{options.map(([key,label]) => <option key={key} value={key}>{label}</option>)}</select>; }
function Actions({ back, onBack, next, onNext }: { back?: boolean; onBack?: () => void; next: string; onNext: () => void }) { return <div className="actions">{back && <button className="secondary" onClick={onBack}>Voltar</button>}<button className="primary" onClick={onNext}>{next}</button></div>; }

function HistoryView({ title, subtitle, materials, search, setSearch, openMaterial, remove, ready }: { title: string; subtitle: string; materials: Material[]; search: string; setSearch: (value: string) => void; openMaterial: (id: string) => void; remove: (id: string) => Promise<void>; ready?: boolean }) { return <section className={`workspace list-page ${ready ? "ready-page" : "history-page"}`}><div className="page-heading"><p className="eyebrow">Central de Conteúdo com IA</p><h1>{title}</h1><p>{subtitle}</p></div><label className="search"><Search /><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Buscar por título, turma ou professor(a)" /></label>{materials.length ? <div className={ready ? "cards" : "material-list"}>{materials.map((item) => ready ? <article className="ready-card" key={item.id}><div><Clock3 /><span>{new Date(item.createdAt).toLocaleDateString("pt-BR")}</span></div><h2>{item.title}</h2><p>{item.audience}</p><button onClick={() => openMaterial(item.id)}>Abrir e baixar</button></article> : <article className="material-row" key={item.id}><button className="row-main" onClick={() => openMaterial(item.id)}><i></i><span><h2>{item.title}</h2><p>{item.audience} · {item.outputTypes.map((value) => labelOf(outputTypes,value)).join(", ")}</p><small>{new Date(item.createdAt).toLocaleString("pt-BR")}</small></span></button><div><button onClick={() => openMaterial(item.id)}>Abrir</button><button className="danger-link" onClick={() => void remove(item.id)}><Trash2 /> Excluir</button></div></article>)}</div> : <Empty text="Nenhum material encontrado." action="Atualizar busca" onAction={() => setSearch("")} />}</section>; }

function SettingsView({ ai, setAI }: { ai: AISettings; setAI: React.Dispatch<React.SetStateAction<AISettings>> }) { const preset = aiProviders.find((item) => item[0] === ai.provider); const isOllama = ai.provider === "ollama"; const isLocalOllama = isOllama && /host\.docker\.internal|localhost|127\.0\.0\.1/i.test(ai.baseUrl); return <section className="workspace settings-page"><div className="page-heading"><p className="eyebrow">Central de Conteúdo com IA</p><h1>Configurações de IA</h1><p>O sistema está preparado para usar o Ollama com o modelo gemma4:cloud.</p></div><div className="settings-card"><SectionTitle step="Provedor" title="Serviço de geração" /><Field label="Provedor de IA"><Select value={ai.provider} options={aiProviders} onChange={(provider) => { const item = aiProviders.find((entry) => entry[0] === provider)!; setAI((current) => ({ ...current, provider, model: item[2], baseUrl: item[3], apiKey: "" })); }} /></Field><div className="fields two"><Field label="Modelo"><input value={ai.model} onChange={(event) => setAI((current) => ({ ...current, model: event.target.value }))} /></Field><Field label="URL da API"><input value={ai.baseUrl} onChange={(event) => setAI((current) => ({ ...current, baseUrl: event.target.value }))} placeholder={preset?.[3]} /></Field></div><hr /><SectionTitle step="Credencial protegida" title={isLocalOllama ? "Ollama autenticado no computador" : "Chave do próprio professor"} /><Field label="Chave da API"><input type="password" autoComplete="off" value={ai.apiKey} onChange={(event) => setAI((current) => ({ ...current, apiKey: event.target.value }))} placeholder={isLocalOllama ? "Deixe vazio e use ollama login no computador" : "Cole sua chave apenas durante o uso"} /></Field><div className="credential"><span className={ai.apiKey || isLocalOllama ? "configured" : ""}></span>{isLocalOllama ? "Execute ollama login e ollama pull gemma4:cloud no computador. Nenhuma chave precisa ser colada aqui." : "A chave fica somente na memória desta página e é apagada ao fechar ou atualizar o navegador."}</div></div></section>; }

function Detail({ material, setMaterials, remove, storageMode }: { material: Material; setMaterials: React.Dispatch<React.SetStateAction<Material[]>>; remove: (id: string) => Promise<void>; storageMode: "database" | "browser" }) {
  const [editing, setEditing] = useState(false);
  const [content, setContent] = useState(material.content);
  const hasPresentation = material.outputTypes.some((type) => type === "presentation" || type === "all") || /^##\s+.*apresenta/im.test(content);
  useEffect(() => { setContent(material.content); setEditing(false); }, [material.id, material.content]);
  const save = async () => {
    if (storageMode === "database") {
      const response = await fetch(`/api/materials/${material.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content }) });
      if (!response.ok) { alert("Não foi possível salvar a alteração."); return; }
    }
    setMaterials((items) => items.map((item) => item.id === material.id ? { ...item, content } : item));
    setEditing(false);
  };
  return <section className="workspace detail-page">
    <div className="page-heading"><p className="eyebrow">Material gerado</p><h1>{material.title}</h1><p>{material.audience} · {material.model}</p></div>
    <div className="detail-layout">
      <aside className="detail-aside"><h2>Exportar</h2>{(["docx", "pptx", "md", "txt"] as const).map((format) => <button key={format} disabled={format === "pptx" && !hasPresentation} title={format === "pptx" && !hasPresentation ? "Gere novamente selecionando Apresentação para os alunos (PowerPoint)." : undefined} onClick={() => exportMaterial(material.title, content, format, material.teacherName, material.images || [])}><Download />{format === "docx" ? "Word" : format === "pptx" ? "PowerPoint" : format === "md" ? "Markdown" : "Texto"}</button>)}{!hasPresentation && <p className="export-note">Para criar slides próprios para os alunos, gere novamente selecionando “Apresentação para os alunos (PowerPoint)”.</p>}<button className="delete" onClick={() => void remove(material.id)}><Trash2 />Excluir material</button></aside>
      <div className="detail-main">
        <article className="document"><div className="document-toolbar"><span>Versão atual</span><div>{editing ? <><button onClick={() => { setContent(material.content); setEditing(false); }}>Cancelar</button><button className="primary" onClick={save}>Salvar</button></> : <button onClick={() => setEditing(true)}>Editar conteúdo</button>}</div></div>{editing ? <textarea className="editor" value={content} onChange={(event) => setContent(event.target.value)} /> : <div className="markdown">{content.split("\n").map((line, index) => /^\s*\[?IMAGEM_\d+\]?\s*$/i.test(line) ? null : line.startsWith("# ") ? <h1 key={index}>{line.slice(2)}</h1> : line.startsWith("## ") ? <h2 key={index}>{line.slice(3)}</h2> : line.startsWith("### ") ? <h3 key={index}>{line.slice(4)}</h3> : line.startsWith("- ") ? <li key={index}>{line.slice(2)}</li> : line.startsWith("> ") ? <blockquote key={index}>{line.slice(2)}</blockquote> : <p key={index}>{line.replace(/\*\*/g, "").replace(/\[?IMAGEM_\d+\]?/gi, "") || " "}</p>)}</div>}</article>
        <ImageLibrary material={material} />
      </div>
    </div>
  </section>;
}

function ImageLibrary({ material }: { material: Material }) {
  const images = material.images || [];
  return <section className="image-library">
    <header><div><p className="eyebrow">Pasta vinculada</p><h2>Imagens do material</h2><p>{images.length ? `${images.length} imagens extraídas e salvas nesta máquina.` : "Nenhuma imagem de conteúdo foi encontrada nos arquivos enviados."}</p></div>{images.length > 0 && <a className="image-folder-download" href={`/api/materials/${material.id}/images/download`}><FolderArchive />Baixar pasta (.zip)</a>}</header>
    {images.length > 0 && <div className="image-grid">{images.map((image, index) => <article key={image.id}><a className="image-preview" href={image.url} target="_blank" rel="noreferrer"><img src={image.url} alt={image.context || `Imagem ${index + 1} do material`} loading="lazy" /></a><div><strong>Imagem {index + 1}</strong><span>{image.context || image.sourceName}</span><small>{image.sourceName}</small><nav><a href={image.url} target="_blank" rel="noreferrer">Abrir</a><a href={image.url} download={image.filename || `imagem-${index + 1}`}>Baixar</a></nav></div></article>)}</div>}
  </section>;
}
