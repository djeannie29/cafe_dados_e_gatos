@echo off
cd /d "%~dp0"
(
  echo Central de Conteudo com IA - Diagnostico
  echo Data: %date% %time%
  echo.
  echo === Docker ===
  docker version
  echo.
  echo === Conteineres ===
  docker compose ps
  echo.
  echo === Registros da aplicacao ===
  docker compose logs --tail 250 professor
  echo.
  echo === Registros do banco ===
  docker compose logs --tail 80 database
) > diagnostico.txt 2>&1
echo Diagnostico salvo em:
echo %cd%\diagnostico.txt
pause
