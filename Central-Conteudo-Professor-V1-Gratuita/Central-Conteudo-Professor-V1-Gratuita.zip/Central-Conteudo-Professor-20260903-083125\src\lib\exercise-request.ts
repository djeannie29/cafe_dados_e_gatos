export type ExerciseSelection = {
  outputTypes?: string[];
  outputLabels: string[];
  quantityExercises?: number;
  quantityTrueFalse?: number;
  quantityMultipleChoice?: number;
  quantityDiscursive?: number;
};

const quantity = (value: number | undefined, fallback: number) => Math.max(1, Math.min(50, Number(value) || fallback));

export function selectedExerciseTypes(data: ExerciseSelection) {
  const selected = new Set(data.outputTypes || []);
  const all = selected.has("all");
  const mixedAssessment = selected.has("assessment");
  const types: string[] = [];

  if (all || mixedAssessment || selected.has("exercises")) types.push(`exercícios gerais: ${quantity(data.quantityExercises, 8)}`);
  if (all || mixedAssessment || selected.has("true_false")) types.push(`questões de verdadeiro ou falso: ${quantity(data.quantityTrueFalse, 5)}`);
  if (all || mixedAssessment || selected.has("multiple_choice")) types.push(`questões de múltipla escolha: ${quantity(data.quantityMultipleChoice, 5)}`);
  if (all || mixedAssessment || selected.has("discursive")) types.push(`questões discursivas: ${quantity(data.quantityDiscursive, 3)}`);

  // Compatibilidade com chamadas antigas, que enviavam somente os rótulos.
  if (!data.outputTypes?.length) {
    const labels = data.outputLabels.join(" ").toLowerCase();
    if (/todos os materiais|questões avaliativas completas/.test(labels)) return [
      `exercícios gerais: ${quantity(data.quantityExercises, 8)}`,
      `questões de verdadeiro ou falso: ${quantity(data.quantityTrueFalse, 5)}`,
      `questões de múltipla escolha: ${quantity(data.quantityMultipleChoice, 5)}`,
      `questões discursivas: ${quantity(data.quantityDiscursive, 3)}`,
    ];
    if (/exercícios para alunos/.test(labels)) types.push(`exercícios gerais: ${quantity(data.quantityExercises, 8)}`);
    if (/verdadeiro ou falso/.test(labels)) types.push(`questões de verdadeiro ou falso: ${quantity(data.quantityTrueFalse, 5)}`);
    if (/múltipla escolha/.test(labels)) types.push(`questões de múltipla escolha: ${quantity(data.quantityMultipleChoice, 5)}`);
    if (/discursivas/.test(labels)) types.push(`questões discursivas: ${quantity(data.quantityDiscursive, 3)}`);
  }

  return [...new Set(types)];
}

export function exercisePromptInstruction(data: ExerciseSelection) {
  const selected = selectedExerciseTypes(data);
  if (!selected.length) return "";
  return `\nTipos e quantidades de questões solicitados: ${selected.join("; ")}. Crie EXATAMENTE estes tipos de questão. Não inclua verdadeiro ou falso, múltipla escolha, questões discursivas ou exercícios gerais que não estejam nesta lista.`;
}

export function filterUnrequestedExerciseSections(content: string, outputTypes?: string[]) {
  if (!outputTypes?.length || outputTypes.includes("all") || outputTypes.includes("assessment")) return content;
  const selected = new Set(outputTypes);
  const headingType = (title: string) => {
    if (/verdadeiro\s*(?:ou|e|\/)\s*falso/i.test(title)) return "true_false";
    if (/m[uú]ltipla\s+escolha/i.test(title)) return "multiple_choice";
    if (/discursiv/i.test(title)) return "discursive";
    if (/(?:exerc[ií]cios|atividades)\s+gerais/i.test(title)) return "exercises";
    return "";
  };
  const lines = content.split(/\r?\n/);
  const kept: string[] = [];
  let skippedLevel = 0;
  for (const line of lines) {
    const heading = /^(#{2,6})\s+(.+)$/.exec(line.trim());
    if (heading) {
      const level = heading[1].length;
      if (skippedLevel && level <= skippedLevel) skippedLevel = 0;
      if (!skippedLevel) {
        const type = headingType(heading[2]);
        if (type && !selected.has(type)) {
          skippedLevel = level;
          continue;
        }
      }
    }
    if (!skippedLevel) kept.push(line);
  }
  return kept.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}
