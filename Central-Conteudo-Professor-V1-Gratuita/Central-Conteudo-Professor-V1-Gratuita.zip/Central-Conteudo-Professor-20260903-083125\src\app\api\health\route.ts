import { NextResponse } from "next/server";
export function GET() { return NextResponse.json({ status: "ok", runtime: "next-open-next", version: "2.0.0", storage: process.env.DATABASE_URL ? "database" : "browser" }); }
