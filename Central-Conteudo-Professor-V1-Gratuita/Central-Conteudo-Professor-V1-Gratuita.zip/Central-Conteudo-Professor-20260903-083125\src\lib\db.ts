import postgres from "postgres";

const globalForDb = globalThis as unknown as { professorSql?: ReturnType<typeof postgres>; professorSchema?: Promise<void> };

export function db() {
  const connection = process.env.DATABASE_URL;
  if (!connection) throw new Error("DATABASE_URL não configurada.");
  const localDatabase = connection.includes("localhost") || connection.includes("127.0.0.1") || connection.includes("@database:") || connection.includes("@db:");
  globalForDb.professorSql ||= postgres(connection, { max: 5, idle_timeout: 20, connect_timeout: 15, ssl: localDatabase ? false : "require" });
  return globalForDb.professorSql;
}

export function hasDatabase() { return Boolean(process.env.DATABASE_URL); }

export async function ensureSchema() {
  globalForDb.professorSchema ||= (async () => {
    const sql = db();
    await sql`CREATE TABLE IF NOT EXISTS users (
      id text PRIMARY KEY,
      name text NOT NULL,
      email text NOT NULL UNIQUE,
      password_hash text NOT NULL,
      created_at timestamptz NOT NULL DEFAULT now()
    )`;
    await sql`CREATE TABLE IF NOT EXISTS sessions (
      token_hash text PRIMARY KEY,
      user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at timestamptz NOT NULL,
      created_at timestamptz NOT NULL DEFAULT now()
    )`;
    await sql`INSERT INTO users (id, name, email, password_hash) VALUES ('local-professor', 'Professor(a)', 'local@device', 'disabled') ON CONFLICT (id) DO NOTHING`;
    await sql`CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions(user_id)`;
    await sql`CREATE TABLE IF NOT EXISTS materials (
      id text PRIMARY KEY,
      user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      title text NOT NULL,
      audience text NOT NULL,
      teacher_name text NOT NULL DEFAULT '',
      source_type text NOT NULL,
      output_types jsonb NOT NULL DEFAULT '[]'::jsonb,
      education_level text NOT NULL,
      pedagogical_model text NOT NULL,
      content text NOT NULL,
      model text NOT NULL,
      status text NOT NULL DEFAULT 'generated',
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now()
    )`;
    await sql`CREATE INDEX IF NOT EXISTS materials_user_created_idx ON materials(user_id, created_at DESC)`;
    await sql`CREATE TABLE IF NOT EXISTS material_images (
      id text PRIMARY KEY,
      material_id text NOT NULL REFERENCES materials(id) ON DELETE CASCADE,
      marker text NOT NULL,
      stored_name text NOT NULL,
      original_name text NOT NULL,
      mime_type text NOT NULL,
      source_name text NOT NULL DEFAULT '',
      context text NOT NULL DEFAULT '',
      width integer NOT NULL DEFAULT 0,
      height integer NOT NULL DEFAULT 0,
      sort_order integer NOT NULL DEFAULT 0,
      created_at timestamptz NOT NULL DEFAULT now()
    )`;
    await sql`CREATE INDEX IF NOT EXISTS material_images_material_idx ON material_images(material_id, sort_order)`;
  })();
  return globalForDb.professorSchema;
}
