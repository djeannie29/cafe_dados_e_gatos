@echo off
cd /d "%~dp0"
docker compose down
echo.
echo Aplicacao encerrada. Os materiais continuam salvos.
pause
